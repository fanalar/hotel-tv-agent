import React, { useCallback, useEffect, useRef, useState } from 'react'
import LiveBg from './components/LiveBg.jsx'
import PersonaCard from './components/PersonaCard.jsx'
import { DevicesPanel, StoryPanel, KbPanel, PrivacyPanel } from './components/Panels.jsx'
import * as api from './lib/api.js'
import { createRecognizer, speechSupported } from './lib/voice.js'

import xiaonuanImg from './assets/xiaonuan.svg'
import azheImg from './assets/azhe.svg'
const IMG = { xiaonuan: xiaonuanImg, azhe: azheImg }

const CHIPS_WELCOME = [
  { t: '我想让小姐姐陪我', pid: 'xiaonuan' },
  { t: '我想让小哥哥陪我', pid: 'azhe' },
]
const CHIPS_STAGE = [
  '讲个晚安故事', '杭州明天天气怎么样', '附近有什么好吃的', '把空调调到26度',
  '拉上窗帘', '用粤语打个招呼', '开灯', '我要退房',
]
const CHIP_HINTS = {
  xiaonuan: ['小暖陪你聊天', '心情不好的时候找我', '我可以讲睡前故事'],
  azhe: ['阿哲随时待命', '聊聊今天的行程', '需要帮助喊我'],
}

function newSession() {
  let s = localStorage.getItem('hota_session')
  if (!s) { s = 'guest-' + Math.random().toString(36).slice(2, 10); localStorage.setItem('hota_session', s) }
  return s
}

export default function App() {
  const [init, setInit] = useState(null)
  const [phase, setPhase] = useState('boot')
  const [persona, setPersona] = useState('xiaonuan')
  const [devices, setDevices] = useState(null)
  const [listening, setListening] = useState(false)
  const [interim, setInterim] = useState('')
  const [speaking, setSpeaking] = useState(false)
  const [userText, setUserText] = useState('')
  const [aiText, setAiText] = useState('')
  const [overlay, setOverlay] = useState(null)
  const [storyText, setStoryText] = useState('')
  const [kbSources, setKbSources] = useState(null)
  const [kbEntries, setKbEntries] = useState([])
  const [sleepMode, setSleepMode] = useState(false)
  const [toast, setToast] = useState(null)
  const [micOn, setMicOn] = useState(true)
  const [msgCount, setMsgCount] = useState(0)
  const [keyboardOpen, setKeyboardOpen] = useState(false)
  const [draft, setDraft] = useState('')

  const sessionRef = useRef(newSession())
  const recRef = useRef(null)
  const busyRef = useRef(false)
  const micOnRef = useRef(true)
  const personaRef = useRef('xiaonuan')
  const phaseRef = useRef('boot')
  const typingTimer = useRef(null)
  const toastTimer = useRef(null)

  useEffect(() => { micOnRef.current = micOn }, [micOn])
  useEffect(() => { personaRef.current = persona }, [persona])
  useEffect(() => { phaseRef.current = phase }, [phase])

  // ---------------- 初始化 ----------------
  useEffect(() => {
    api.apiInit().then((d) => {
      setInit(d); setDevices(d.devices)
      setPersona('xiaonuan')
      setPhase('welcome')
      setToast({ msg: '欢迎入住示例酒店 · 全程语音即可控制', kind: 'ok' })
    }).catch((e) => setToast({ msg: '后端连接失败：' + e.message, kind: 'err' }))
    return () => { if (typingTimer.current) clearTimeout(typingTimer.current); if (toastTimer.current) clearTimeout(toastTimer.current) }
  }, [])

  const showToast = useCallback((msg, kind = 'err') => {
    setToast({ msg, kind })
    if (toastTimer.current) clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToast(null), 3200)
  }, [])

  // ---------------- 打字机效果 ----------------
  const typeText = useCallback((full, cb) => {
    setAiText('')
    let i = 0
    const step = () => {
      i += 1 + Math.round(full.length / 90)
      if (i >= full.length) { setAiText(full); if (cb) cb(); return }
      setAiText(full.slice(0, i))
      typingTimer.current = setTimeout(step, 12)
    }
    step()
  }, [])

  // ---------------- 发送文本到智能体 ----------------
  const sendText = useCallback(async (raw) => {
    const text = (raw || '').trim()
    if (!text || busyRef.current) return
    busyRef.current = true
    setSleepMode(false)
    stopListen()
    setUserText(text)
    setMsgCount((c) => c + 1)
    setInterim('')
    try {
      const resp = await api.agentAsk(sessionRef.current, personaRef.current, text)
      const reply = resp.reply || ''
      const voice = resp.tts_voice
      // 欢迎页首次交互 -> 进入人物舞台（退房除外）
      if (phaseRef.current === 'welcome' && resp.action !== 'checkout_done') setPhase('stage')
      // 动作处理（面板类动作在语音播报同时打开）
      if (resp.action === 'switch') {
        setPersona(resp.persona)
        personaRef.current = resp.persona
        showToast('已切换至' + (resp.persona === 'azhe' ? '阿哲' : '小暖'), 'ok')
        if (resp.panel === 'story') { setStoryText(reply); setOverlay('story') }
      } else if (resp.action === 'checkout_done') {
        setMsgCount(0)
        const ns = 'guest-' + Math.random().toString(36).slice(2, 10)
        sessionRef.current = ns; localStorage.setItem('hota_session', ns)
        setOverlay(null); setSleepMode(false); setPhase('welcome'); setPersona('xiaonuan')
        personaRef.current = 'xiaonuan'
      } else if (resp.action === 'mic_off') { setMicOn(false); setOverlay('privacy') }
      else if (resp.action === 'mic_on') { setMicOn(true); setOverlay('privacy'); startListen() }
      else if (resp.action === 'sleep_scene') { setSleepMode(true); setStoryText(reply); setOverlay('story') }
      else if (resp.action === 'story') { setStoryText(reply); setOverlay('story') }
      else if (resp.action === 'device') { if (resp.devices) setDevices(resp.devices); setOverlay('devices') }
      else if (resp.action === 'kb') {
        setKbSources(resp.sources || null)
        api.kbList().then((r) => setKbEntries(r.entries || [])).catch(() => {})
        setOverlay('kb')
      }
      // 语音播报 + 字幕
      setSpeaking(true)
      typeText(reply)
      const ok = await api.speak(reply, voice)
      setSpeaking(false)
      if (!ok) showToast('语音合成不可用，已切换为字幕模式', 'ok')
    } catch (e) {
      setAiText('抱歉，我暂时没听清/没连上服务，请再试一次。')
      showToast('请求失败：' + e.message)
    } finally {
      busyRef.current = false
      setTimeout(() => { if (micOnRef.current) startListen() }, 700)
    }
  }, [showToast, typeText])

  // ---------------- 语音识别 ----------------
  const startListen = useCallback(() => {
    if (!micOnRef.current || busyRef.current || !speechSupported()) return
    if (recRef.current) { try { recRef.current.start() } catch (_) {} return }
    const rec = createRecognizer({
      onInterim: setInterim,
      onFinal: (t) => sendText(t),
      onError: (code) => {
        if (code === 'not-allowed' || code === 'service-not-allowed') {
          setMicOn(false); setListening(false)
          showToast('未获得麦克风权限，可使用下方文字输入', 'err')
        } else if (code === 'network') {
          setListening(false)
          showToast('语音识别失败，请再试一次', 'err')
        } else if (code === 'aborted') { /* 忽略主动停止 */ }
      },
      onEnd: () => {
        setListening(false)
        if (micOnRef.current && !busyRef.current) setTimeout(() => { if (micOnRef.current && !busyRef.current) startListen() }, 600)
      },
    })
    if (!rec) return
    recRef.current = rec
    try { rec.start(); setListening(true) } catch (_) {}
  }, [sendText, showToast])

  const stopListen = useCallback(() => {
    if (recRef.current) { try { recRef.current.stop() } catch (_) {} recRef.current = null }
    setListening(false); setInterim('')
  }, [])

  // 启停：阶段/麦克风变化
  useEffect(() => {
    if (phase === 'boot') return
    if (micOn) {
      const t = setTimeout(() => startListen(), phase === 'welcome' ? 600 : 400)
      return () => clearTimeout(t)
    }
    stopListen()
  }, [phase, micOn, startListen, stopListen])

  const toggleMic = useCallback(() => {
    const next = !micOn
    setMicOn(next)
    if (next) showToast('麦克风已开启', 'ok')
    else { stopListen(); showToast('麦克风已关闭 · 指示灯熄灭', 'ok') }
  }, [micOn, showToast, stopListen])

  // ---------------- 交互动作 ----------------
  const pickPersona = (pid) => { sendText(pid === 'azhe' ? '我想让小哥哥陪我' : '我想让小姐姐陪我') }
  const doCheckout = async () => {
    await api.checkoutNow()
    sessionRef.current = newSession()
    setMsgCount(0); setOverlay(null); setSleepMode(false); setPhase('welcome')
    setPersona('xiaonuan'); personaRef.current = 'xiaonuan'
    showToast('已退房 · 本房间数据已全部清除', 'ok')
  }
  const replayStory = () => { if (storyText) { setSpeaking(true); api.speak(storyText, init && init.personas[persona].voice).finally(() => setSpeaking(false)) } }
  const openPanel = (p) => {
    setOverlay(p)
    if (p === 'privacy' || p === 'devices' || p === 'kb') { /* no-op refresh below */ }
    if (p === 'kb') api.kbList().then((r) => setKbEntries(r.entries || [])).catch(() => {})
  }

  const hintBar = !init ? '' : phase === 'welcome'
    ? '直接对电视说：「我想让小姐姐陪我」或「我想让小哥哥陪我」'
    : '直接对电视说：「' + CHIP_HINTS[persona][Math.floor(Date.now() / 8000) % 3] + '」· 例如「把空调调到26度」'

  if (!init || !devices) return <div className="tv-app" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9fb3d1' }}>正在连接示例酒店管家服务…</div>

  const p = init.personas[persona]
  const listeningAny = listening && !busyRef.current && phase !== 'boot'
  const panelOpen = overlay !== null

  return (
    <div className="tv-app">
      <LiveBg channel={devices.tv.channel} sleeping={sleepMode} />

      {/* 电视顶部状态 */}
      <div className="topbar">
        <div className="brand-left">
          <span className="badge-5g">5G</span>
          <div>
            <div className="brand-name">演示频道 · 高清</div>
            <div className="brand-sub">{devices.tv.channel} · 数字电视</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span className="live-chip"><span className="dot" />直播中</span>
          <span className="mini-btn" style={{ padding: '5px 11px' }} title="麦克风状态">
            <span className={'led ' + (micOn ? 'on' : '')} style={{ display: 'inline-block', marginRight: 6, verticalAlign: 'middle' }} />
            {micOn ? '收音中' : '已静音'}
          </span>
        </div>
      </div>
      <div className="top-hint">{hintBar}</div>

      {/* ============ 欢迎选择 ============ */}
      {phase === 'welcome' && (
        <div className="welcome">
          <h1>欢迎入住，请选择您的陪伴管家</h1>
          <div className="sub">直接对电视说：<b>「我想让小姐姐陪我」</b> 或 <b>「我想让小哥哥陪我」</b></div>
          <div className="persona-cards">
            <PersonaCard pid="xiaonuan" persona={init.personas.xiaonuan} listening={listeningAny && persona !== 'xiaonuan'} onPick={pickPersona} />
            <PersonaCard pid="azhe" persona={init.personas.azhe} listening={listeningAny && persona !== 'azhe'} onPick={pickPersona} />
          </div>
          <div className="listen-row">
            <span className={'listen-dot' + (listeningAny ? '' : '')} style={{ opacity: listeningAny ? 1 : 0.35 }} />
            {listeningAny ? '正在聆听您的选择…' : interim ? interim : '请对着电视说话'}
            {interim && <span style={{ color: '#ffd27a' }}>{interim}</span>}
            <span className="wave"><i /><i /><i /><i /><i /></span>
          </div>
          <div className="chip-bar">
            <span className="lb">或点选：</span>
            {CHIPS_WELCOME.map((c) => <span key={c.pid} className="chip hot" onClick={() => pickPersona(c.pid)}>{c.t}</span>)}
          </div>
        </div>
      )}

      {/* ============ 人物舞台 ============ */}
      {phase === 'stage' && (
        <div className={'stage-view' + (panelOpen ? ' panel-open' : '')}>
          <div className="stage-avatar-wrap">
            <span className={'ring' + (speaking ? ' pulse' : '')} />
            <span className={'ring' + (listeningAny ? ' pulse' : '')} style={{ animationDelay: '.5s' }} />
            <img className={'stage-avatar' + (speaking ? ' speaking' : '')} src={IMG[persona]} alt={p.name} />
          </div>
          <div className="stage-voice-tag"><b>{p.name}</b> · {p.tag}</div>
          <div className="caption-zone">
            {userText && <div className="user-line">{userText}</div>}
            <div className={'ai-line' + (speaking ? ' caret' : '')}>{aiText || (speaking ? '……' : '')}</div>
            <div className="mic-hint-row">
              {speaking
                ? <span>🔊 正在播报…</span>
                : listeningAny
                  ? <><span className="listen-dot" />正在聆听… {interim && <span style={{ color: '#ffd27a' }}>{interim}</span>}</>
                  : busyRef.current ? <span>思考中…</span> : <span style={{ color: '#5c7299' }}>对着电视说话即可（或点下方指令）</span>}
            </div>
          </div>
        </div>
      )}

      {/* 语音指令条 */}
      <div className="chip-bar" style={{ bottom: phase === 'stage' ? 96 : undefined }}>
        {phase === 'welcome'
          ? <><span className="lb">语音或点选</span>{CHIPS_WELCOME.map((c) => <span key={c.pid} className="chip" onClick={() => pickPersona(c.pid)}>{c.t}</span>)}</>
          : <><span className="lb">试试说：</span>{CHIPS_STAGE.map((c) => <span key={c} className="chip" onClick={() => sendText(c)}>{c}</span>)}
            <span className="chip" onClick={() => openPanel('privacy')}>🔒 隐私</span>
            <span className="chip" onClick={() => openPanel('devices')}>🎛️ 设备</span>
            <span className="chip" onClick={() => openPanel('kb')}>🏨 知识库</span>
          </>}
      </div>

      {/* 新闻跑马灯 */}
      <div className="news-ticker">
        <span className="news-tag">新闻纵横</span>
        <div className="news-track">
          <div className="news-inner">
            {[...init.news, ...init.news].map((n, i) => <span key={i}>{n}</span>)}
          </div>
        </div>
      </div>

      {/* 角落按钮：文字输入兜底 */}
      <div className="corner-btns">
        <button className="mini-btn" onClick={() => setKeyboardOpen(true)} title="文字输入（遥控器键盘备用）">⌨️ 文字输入</button>
      </div>

      {/* 睡前氛围 */}
      {sleepMode && <div className="sleep-shade"><div className="moon" /></div>}

      {/* Toast */}
      {toast && <div className={'toast ' + (toast.kind || '')}>{toast.msg}</div>}

      {/* ============ 面板 ============ */}
      {overlay === 'devices' && <DevicesPanel devices={devices} onClose={() => setOverlay(null)} onChanged={setDevices} />}
      {overlay === 'story' && storyText && <StoryPanel story={storyText} onClose={() => setOverlay(null)} onReplay={replayStory} />}
      {overlay === 'kb' && (
        <KbPanel entries={kbEntries} sources={kbSources} onClose={() => setOverlay(null)}
          onRefresh={() => api.kbList().then((r) => setKbEntries(r.entries || [])).catch(() => {})} />
      )}
      {overlay === 'privacy' && (
        <PrivacyPanel micOn={micOn} onMicToggle={toggleMic} msgCount={msgCount} onCheckout={doCheckout} onClose={() => setOverlay(null)} />
      )}

      {/* 文字输入兜底 */}
      {keyboardOpen && (
        <div className="keyboard-overlay" onClick={(e) => e.target === e.currentTarget && setKeyboardOpen(false)}>
          <div className="keyboard-box">
            <h3>⌨️ 文字输入（演示语音异常时的备用通道）</h3>
            <input className="inp" autoFocus placeholder="例如：把空调调到22度 / 附近有什么好吃的 / 我要退房"
              value={draft} onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && draft.trim()) { sendText(draft); setDraft(''); setKeyboardOpen(false) } }} />
            <div className="text-send-row">
              <button className="btn" onClick={() => { if (draft.trim()) { sendText(draft); setDraft(''); setKeyboardOpen(false) } }}>发送</button>
              <button className="btn ghost" onClick={() => setKeyboardOpen(false)}>取消</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
