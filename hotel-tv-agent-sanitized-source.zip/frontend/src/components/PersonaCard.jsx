import React from 'react'
import xiaonuan from '../assets/xiaonuan.svg'
import azhe from '../assets/azhe.svg'

const IMG = { xiaonuan, azhe }

export default function PersonaCard({ pid, persona, listening, hot, onPick }) {
  return (
    <div className={'persona-card' + (hot ? ' hot' : '')} onClick={() => onPick(pid)}>
      <img className="ph" src={IMG[pid]} alt={persona.name} draggable={false} />
      <div className="meta">
        <div className="nm">{persona.name}</div>
        <div className="tg">{persona.tag}</div>
      </div>
      {listening && <div style={{ position: 'absolute', top: 10, right: 10, display: 'flex', gap: 3 }}>
        {[0, 1, 2].map(i => <i key={i} style={{ width: 3, background: '#fff', borderRadius: 2, height: 8 }} />)}
      </div>}
    </div>
  )
}
