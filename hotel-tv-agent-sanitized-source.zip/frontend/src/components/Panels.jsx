import React, { useState, useEffect } from 'react'
import { deviceSet, kbImport } from '../lib/api'

export function DevicesPanel({ devices, onClose, onChanged }) {
  const set = async (key, patch) => { const d = await deviceSet(key, patch); onChanged(d) }
  const L = devices.light, A = devices.ac, C = devices.curtain, T = devices.tv
  if (!L) return null
  return (
    <div className="panel-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="panel">
        <button className="close-x" onClick={onClose}>✕</button>
        <h2>🎛️ 房间设备控制</h2>
        <div className="dev-grid">
          <div className="dev-card">
            <div className="ico">💡</div><div className="dn">{L.label}</div>
            <div className={'st ' + (L.on ? 'on' : '')}>{L.on ? '已开启 · ' + L.brightness + '%' : '已关闭'}</div>
            <button className={'switch ' + (L.on ? 'on' : '')} onClick={() => set('light', { on: !L.on })} />
            <div className="range-row">亮度 <input type="range" min={5} max={100} value={L.brightness}
              onChange={(e) => set('light', { on: true, brightness: +e.target.value })} /></div>
          </div>
          <div className="dev-card">
            <div className="ico">❄️</div><div className="dn">{A.label}</div>
            <div className={'st ' + (A.on ? 'on' : '')}>{A.on ? '制冷 ' + A.temp + '℃' : '已关闭'}</div>
            <button className={'switch ' + (A.on ? 'on' : '')} onClick={() => set('ac', { on: !A.on })} />
            <div className="range-row">温度 <input type="range" min={16} max={30} value={A.temp}
              onChange={(e) => set('ac', { on: true, temp: +e.target.value })} /> {A.temp}℃</div>
          </div>
          <div className="dev-card">
            <div className="ico">🪟</div><div className="dn">{C.label}</div>
            <div className={'st ' + (C.open > 5 ? 'on' : '')}>{C.open > 5 ? '开启 ' + C.open + '%' : '已关闭'}</div>
            <div className="range-row">开合 <input type="range" min={0} max={100} value={C.open}
              onChange={(e) => set('curtain', { open: +e.target.value })} /> {C.open}%</div>
          </div>
          <div className="dev-card">
            <div className="ico">📺</div><div className="dn">{T.label}</div>
            <div className={'st ' + (T.on ? 'on' : '')}>{T.on ? T.channel : '已关闭'}</div>
            <button className={'switch ' + (T.on ? 'on' : '')} onClick={() => set('tv', { on: !T.on })} />
            <div className="range-row">音量 <input type="range" min={0} max={100} value={T.volume}
              onChange={(e) => set('tv', { on: true, volume: +e.target.value })} /> {T.volume}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export function StoryPanel({ story, onClose, onReplay }) {
  return (
    <div className="panel-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="panel">
        <button className="close-x" onClick={onClose}>✕</button>
        <h2>🌙 晚安故事</h2>
        <div className="story-body">{story}</div>
        <div className="story-acts">
          <button className="btn" onClick={onReplay}>🔊 重新播放</button>
          <button className="btn ghost" onClick={onClose}>关闭</button>
        </div>
      </div>
    </div>
  )
}

export function KbPanel({ entries, sources, onClose, onRefresh }) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [cat, setCat] = useState('自定义')
  const [msg, setMsg] = useState('')
  const submit = async () => {
    if (!title.trim() || !content.trim()) { setMsg('请填写标题与内容'); return }
    await kbImport(cat, title.trim(), content.trim())
    setTitle(''); setContent(''); setMsg('已导入 ✓'); onRefresh(); setTimeout(() => setMsg(''), 1800)
  }
  return (
    <div className="panel-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="panel">
        <button className="close-x" onClick={onClose}>✕</button>
        <h2>🏨 酒店知识库</h2>
        {sources && sources.length > 0 && (
          <>
            <div className="kb-cat"><span className="chip hot">本次回答依据</span></div>
            {sources.map((s, i) => (
              <div className="kb-item" key={i}><div className="t">📌 {s.title}</div><div className="c">{s.content}</div></div>
            ))}
          </>
        )}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '14px 0 8px' }}>
          <b>知识条目（{entries.length}）</b>
          <button className="btn ghost" onClick={onRefresh}>刷新</button>
        </div>
        {entries.slice(0, 40).map((e) => (
          <div className="kb-item" key={e.id}>
            <div className="t">{e.title} <span style={{ color: '#6f86ad', fontWeight: 400, fontSize: 13 }}>· {e.category}</span></div>
            <div className="c">{e.content}</div>
          </div>
        ))}
        <div style={{ marginTop: 16 }}>
          <b>📥 导入知识（模拟酒店后台给 PDF/资料即建库）</b>
          <div className="kb-import">
            <input className="inp" placeholder="标题（如：周边景点）" value={title} onChange={(e) => setTitle(e.target.value)} />
            <input className="inp" placeholder="分类（默认 自定义）" value={cat} onChange={(e) => setCat(e.target.value)} style={{ maxWidth: 150 }} />
          </div>
          <textarea className="inp" style={{ marginTop: 8 }} placeholder="内容：一句话知识，保存后智能体会据此回答…"
            value={content} onChange={(e) => setContent(e.target.value)} />
          <div style={{ marginTop: 8 }}>
            <button className="btn" onClick={submit}>导入知识库</button>
            <span style={{ marginLeft: 12, color: '#37d67a' }}>{msg}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export function PrivacyPanel({ micOn, onMicToggle, msgCount, onCheckout, onClose }) {
  return (
    <div className="panel-backdrop" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="panel">
        <button className="close-x" onClick={onClose}>✕</button>
        <h2>🔒 隐私合规中心</h2>
        <div className="privacy-items">
          <div className="priv-card">
            <h3>🎙️ 麦克风物理开关</h3>
            <div className="priv-led"><span className={'led ' + (micOn ? 'on' : '')} />{micOn ? '麦克风开启 · 常亮指示灯亮起' : '麦克风已关闭 · 指示灯熄灭'}</div>
            <button className={'switch ' + (micOn ? 'on' : '')} onClick={onMicToggle} style={{ margin: '6px 0 0' }} />
            <p style={{ color: 'var(--txt-dim)', fontSize: 14, lineHeight: 1.6 }}>真实硬件上为物理拨动开关，关闭后设备彻底停止收音。演示中以红色常亮指示灯表示收音中。</p>
          </div>
          <div className="priv-card">
            <h3>🧹 退房即清</h3>
            <p style={{ color: 'var(--txt-dim)', fontSize: 14 }}>当前会话共 <b style={{ color: '#fff' }}>{msgCount}</b> 条对话记录，仅存本机。办理退房后全部删除、设备恢复默认，客人数据零留存。</p>
            <button className="btn danger big-danger" onClick={onCheckout}>🧳 我要退房 · 一键清除全部数据</button>
          </div>
        </div>
      </div>
    </div>
  )
}
