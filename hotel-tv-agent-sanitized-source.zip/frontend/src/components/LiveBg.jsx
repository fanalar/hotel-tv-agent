import React, { useEffect, useMemo, useRef } from 'react'

// 夜空：星星 + 城市天际线（SVG）
export default function LiveBg({ channel, sleeping }) {
  const stars = useMemo(() => {
    const rnd = (() => { let s = 42; return () => (s = (s * 16807) % 2147483647) / 2147483647 })()
    return Array.from({ length: 130 }, () => ({
      x: rnd() * 100, y: rnd() * 68, s: 0.6 + rnd() * 1.9, o: 0.35 + rnd() * 0.6, tw: 2 + rnd() * 4,
    }))
  }, [])

  // 城市天际线：确定性伪随机窗灯
  const skyline = useMemo(() => {
    const rnd = (() => { let s = 7; return () => (s = (s * 48271) % 2147483647) / 2147483647 })()
    const blocks = []
    let x = 0
    while (x < 100) {
      const bw = 3 + rnd() * 6
      const bh = 10 + rnd() * 26
      blocks.push({ x, w: bw, h: bh })
      x += bw + 0.6
    }
    return blocks.map((b, bi) => {
      const win = []
      for (let wy = b.h - 3; wy > 4; wy -= 4.2) {
        for (let wx = b.x + 0.8; wx < b.x + b.w - 0.8; wx += 1.6) {
          if (rnd() > 0.52) win.push({ x: wx, y: wy })
        }
      }
      return <g key={bi}>
        <rect x={b.x} y={100 - b.h} width={b.w} height={b.h} fill="#040b1c" />
        {win.map((p, wi) => <rect key={wi} x={p.x} y={100 - p.y} width={0.55} height={0.75}
          fill={rnd() > 0.6 ? '#ffd98a' : '#8fc3ff'} opacity={0.55 + rnd() * 0.4} />)}
      </g>
    })
  }, [])

  return (
    <div className="live-bg">
      <div className="stars">
        {stars.map((s, i) => (
          <span key={i} style={{
            position: 'absolute', left: s.x + '%', top: s.y + '%', width: s.s, height: s.s,
            background: '#fff', borderRadius: '50%', opacity: s.o,
            animation: `blink ${s.tw}s ease-in-out infinite`,
            boxShadow: '0 0 4px rgba(255,255,255,.8)',
          }} />
        ))}
      </div>
      <div className="glow" />
      {!sleeping && (
        <svg className="skyline" viewBox="0 0 100 100" preserveAspectRatio="none">
          {skyline}
        </svg>
      )}
    </div>
  )
}
