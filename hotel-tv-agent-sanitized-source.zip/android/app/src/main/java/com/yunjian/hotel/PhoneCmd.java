package com.yunjian.hotel;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 手机助手指令：识别 + 经无障碍服务执行（无需 root） */
public final class PhoneCmd {
    private PhoneCmd() {}

    static final Pattern OPEN = Pattern.compile("^(打开|启动|帮我打开|给我打开)(.{1,16})$");
    static final Pattern VOL_UP = Pattern.compile("音量(加大|调大|大点|大一点|开大)");
    static final Pattern VOL_DOWN = Pattern.compile("音量(调小|减小|小点|小一点|关小)");
    static final Pattern BRI_UP = Pattern.compile("亮度(调高|调亮|大一点|最高|拉满)|屏幕(调亮|亮一点)");
    static final Pattern BRI_DOWN = Pattern.compile("亮度(调暗|调低|小一点|最低)|屏幕(调暗|暗一点)");

    static String strip(String t) { return t.replaceAll("[\\s，。！？、；：“”‘’（）【】《》,.!?;:()\\[\\]·\\-—~～]", ""); }

    public static boolean isPhoneCommand(String text) {
        String t = strip(text);
        if (OPEN.matcher(t).find()) return true;
        if (t.equals("返回") || t.contains("后退") || t.contains("回退")) return true;
        if (t.contains("回桌面") || t.equals("桌面") || t.contains("回主屏") || t.contains("主页")) return true;
        if (t.contains("最近任务") || t.contains("多任务") || t.contains("后台应用") || t.contains("切换应用")) return true;
        if (t.contains("通知栏") || t.contains("下拉通知") || t.contains("看通知")) return true;
        if (VOL_UP.matcher(t).find() || t.contains("声音大点") || t.contains("大声点")) return true;
        if (VOL_DOWN.matcher(t).find() || t.contains("声音小点") || t.contains("小声点") || t.equals("静音")) return true;
        if (BRI_UP.matcher(t).find()) return true;
        if (BRI_DOWN.matcher(t).find()) return true;
        return false;
    }

    public static String execute(Context ctx, String text) {
        String t = strip(text);
        Matcher m = OPEN.matcher(t);
        if (m.find()) {
            String app = m.group(2);
            if (app.startsWith("手机") && (app.contains("设置") || app.contains("应用"))) return "这个交给您手动操作更稳妥～";
            return run("open_app", app);
        }
        if (t.equals("返回") || t.contains("后退") || t.contains("回退")) return run("back", null);
        if (t.contains("回桌面") || t.equals("桌面") || t.contains("回主屏") || t.contains("主页")) return run("home", null);
        if (t.contains("最近任务") || t.contains("多任务") || t.contains("后台应用") || t.contains("切换应用")) return run("recents", null);
        if (t.contains("通知栏") || t.contains("下拉通知") || t.contains("看通知")) return run("notifications", null);
        if (VOL_UP.matcher(t).find() || t.contains("声音大点") || t.contains("大声点")) return run("volume_up", null);
        if (VOL_DOWN.matcher(t).find() || t.contains("声音小点") || t.contains("小声点")) return run("volume_down", null);
        if (t.equals("静音")) return run("volume_mute", null);
        if (BRI_UP.matcher(t).find()) {
            if (t.contains("最高") || t.contains("拉满")) return run("brightness_max", null);
            return run("brightness_up", null);
        }
        if (BRI_DOWN.matcher(t).find()) {
            if (t.contains("最低")) return run("brightness_min", null);
            return run("brightness_down", null);
        }
        return "这个手机操作我还不支持，试试「返回 / 回桌面 / 打开微信 / 音量调大 / 亮度调暗」";
    }

    private static String run(String action, String param) {
        if (!PhoneAssistService.running) {
            return "手机助手还没开启。请到「隐私中心 → 手机助手」开启无障碍服务，之后就能用语音操控手机啦。";
        }
        String r = PhoneAssistService.exec(action, param);
        return r != null ? r : "手机助手未就绪，请先开启无障碍服务";
    }

    public static void openAccessibilitySettings(Context ctx) {
        try {
            ctx.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable ignored) {}
    }

    public static void openWriteSettings(Context ctx) {
        try {
            Intent it = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    android.net.Uri.parse("package:" + ctx.getPackageName()));
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(it);
        } catch (Throwable ignored) {}
    }
}
