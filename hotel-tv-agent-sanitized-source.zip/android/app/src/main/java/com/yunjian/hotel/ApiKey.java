package com.yunjian.hotel;
public final class ApiKey { public static final String VALUE = ""; private ApiKey() {} }
