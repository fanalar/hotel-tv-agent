package com.yunjian.hotel;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;

/** 手机助手无障碍服务：语音指令操控手机（无需 root） */
public class PhoneAssistService extends AccessibilityService {

    public static volatile boolean running = false;
    private static PhoneAssistService inst;
    private static final Handler h = new Handler(Looper.getMainLooper());

    public static PhoneAssistService get() { return inst; }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        running = true;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {}

    @Override
    public void onInterrupt() {}

    @Override
    public boolean onUnbind(Intent intent) {
        running = false;
        inst = null;
        return super.onUnbind(intent);
    }

    /** 返回执行结果文案（失败返回 null 语义错误消息） */
    public static String exec(String action, String param) {
        PhoneAssistService s = inst;
        if (s == null || !running) return null; // 未开启
        switch (action) {
            case "back": return s.performGlobalAction(GLOBAL_ACTION_BACK) ? "好的，已返回" : "返回失败";
            case "home": return s.performGlobalAction(GLOBAL_ACTION_HOME) ? "好的，已回到桌面" : "失败";
            case "recents": return s.performGlobalAction(GLOBAL_ACTION_RECENTS) ? "好的，已打开最近任务" : "失败";
            case "notifications": return s.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ? "好的，已下拉通知栏" : "失败";
            case "volume_up": s.adjustVolume(AudioManager.ADJUST_RAISE); return "音量已调大";
            case "volume_down": s.adjustVolume(AudioManager.ADJUST_LOWER); return "音量已调小";
            case "volume_mute": s.adjustVolume(AudioManager.ADJUST_MUTE); return "已静音";
            case "brightness_up": return s.setBrightness(+35);
            case "brightness_down": return s.setBrightness(-35);
            case "brightness_max": return s.setBrightness(255);
            case "brightness_min": return s.setBrightness(30);
            case "open_app": return s.openApp(param);
            default: return "暂不支持该操作";
        }
    }

    private void adjustVolume(int dir) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
    }

    private String setBrightness(int deltaOrAbs) {
        try {
            if (!Settings.System.canWrite(this)) return "需要授权「修改系统设置」，请点隐私中心→授权修改系统设置";
            int mode = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC);
            if (mode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC) {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            }
            int cur = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
            int target = (deltaOrAbs == 255 || deltaOrAbs == 30) ? deltaOrAbs : Math.max(10, Math.min(255, cur + deltaOrAbs));
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, target);
            return "屏幕亮度已调整到 " + Math.round(target / 255f * 100) + "%";
        } catch (Throwable t) {
            return "亮度调整失败：" + (t.getMessage() == null ? "未授权" : t.getMessage());
        }
    }

    private String openApp(String name) {
        if (name == null || name.isEmpty()) return "请告诉我要打开哪个应用，比如「打开微信」";
        PackageManager pm = getPackageManager();
        String best = null;
        String bestLabel = "";
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) == 0 || true) {
                String label = String.valueOf(pm.getApplicationLabel(ai));
                if (label.toLowerCase().contains(name.toLowerCase())) {
                    if (label.length() < bestLabel.length() || bestLabel.isEmpty()) {
                        bestLabel = label;
                        best = ai.packageName;
                    }
                }
            }
        }
        if (best == null) return "没找到「" + name + "」这个应用，换个名字试试？";
        Intent launch = pm.getLaunchIntentForPackage(best);
        if (launch == null) return "「" + bestLabel + "」没有可启动界面";
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(launch); return "好的，正在打开「" + bestLabel + "」"; }
        catch (Throwable t) { return "打开「" + bestLabel + "」失败"; }
    }
}
