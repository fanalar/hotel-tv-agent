package com.yunjian.hotel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Locale;

/** 网络：DeepSeek(OpenAI 兼容) / Open-Meteo 天气 / 必应搜索。阻塞方法，须在子线程调用 */
public final class Net {
    private Net() {}

    public static final int TIMEOUT = 25000;

    static String http(String method, String url, String body, String bearer, boolean shortTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(shortTimeout ? 8000 : TIMEOUT);
        c.setReadTimeout(shortTimeout ? 12000 : TIMEOUT);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) YunjianHotelAgent/2.0");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        }
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        int code = -1;
        try {
            if (body != null) {
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes("UTF-8")); }
            }
            code = c.getResponseCode();
        } catch (Exception e) {
            code = c.getResponseCode(); // may rethrow
        }
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                String l;
                while ((l = br.readLine()) != null) sb.append(l).append('\n');
            }
        }
        String text = sb.toString();
        if (code >= 400) throw new Exception("HTTP " + code + " " + (text.length() > 300 ? text.substring(0, 300) : text));
        return text;
    }

    /** DeepSeek 对话。messages: [{role,system/user/assistant,content}] */
    public static String chat(String base, String model, String key, JSONArray messages, int maxTokens) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("messages", messages);
        body.put("temperature", 0.7);
        body.put("max_tokens", maxTokens);
        String out = http("POST", base + "/chat/completions", body.toString(), key, false);
        JSONObject j = new JSONObject(out);
        return j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim();
    }

    /** 模型失败时降级尝试常见名字 */
    public static String chatWithFallback(String base, String key, JSONArray messages, int maxTokens) throws Exception {
        String[] models = {C.DEF_MODEL, "deepseek-chat", "deepseek-v3"};
        Exception last = null;
        for (String m : models) {
            try { return chat(base, m, key, messages, maxTokens); }
            catch (Exception e) { last = e; }
        }
        throw last != null ? last : new Exception("LLM failed");
    }

    // ---------------- 天气 ----------------
    /** 反向地理编码：经纬度 -> 城市名（免费无 key） */
    public static String reverseCity(double lat, double lon) {
        try {
            String url = String.format(Locale.US,
                "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=%.5f&longitude=%.5f&localityLanguage=zh", lat, lon);
            String out = http("GET", url, null, null, true);
            JSONObject j = new JSONObject(out);
            String city = j.optString("city", "");
            if (city.isEmpty()) city = j.optString("locality", "");
            if (!city.isEmpty()) {
                city = city.replace("市", "").replace("省", "").replace("特别行政区", "").trim();
                return city;
            }
        } catch (Exception ignored) {}
        return null;
    }

    static String cityPinyin(String zh) {
        for (String[] c : C.CITIES) if (zh.contains(c[0])) return c[1];
        return null;
    }
    static double[] cityCoord(String pinyin) {
        // name -> (lat,lon) 兜底
        switch (pinyin) {
            case "beijing": return new double[]{39.90, 116.40};
            case "shanghai": return new double[]{31.23, 121.47};
            case "guangzhou": return new double[]{23.13, 113.26};
            case "shenzhen": return new double[]{22.54, 114.06};
            case "hangzhou": return new double[]{30.27, 120.16};
            case "chengdu": return new double[]{30.57, 104.07};
            case "chongqing": return new double[]{29.56, 106.55};
            case "wuhan": return new double[]{30.59, 114.31};
            case "xian": return new double[]{34.34, 108.94};
            case "nanjing": return new double[]{32.06, 118.80};
            case "tianjin": return new double[]{39.13, 117.20};
            case "suzhou": return new double[]{31.30, 120.58};
            case "changsha": return new double[]{28.23, 112.94};
            case "qingdao": return new double[]{36.07, 120.38};
            case "xiamen": return new double[]{24.48, 118.09};
            case "kunming": return new double[]{25.04, 102.71};
            case "sanya": return new double[]{18.25, 109.51};
            case "haerbin": return new double[]{45.80, 126.53};
            case "wulumuqi": return new double[]{43.83, 87.62};
            case "lasa": return new double[]{29.65, 91.14};
            default: return null;
        }
    }

    // ---------------- 天气（中国天气网优先，免 key、国内可达） ----------------
    static String cityCode(String zh) {
        String[][] m = {
            {"北京","101010100"},{"上海","101020100"},{"天津","101030100"},{"重庆","101040100"},
            {"哈尔滨","101050101"},{"长春","101060101"},{"沈阳","101070101"},{"呼和浩特","101080101"},
            {"石家庄","101090101"},{"太原","101100101"},{"西安","101110101"},{"济南","101120101"},
            {"郑州","101180101"},{"南京","101190101"},{"杭州","101210101"},{"合肥","101220101"},
            {"武汉","101200101"},{"长沙","101250101"},{"南昌","101240101"},{"福州","101230101"},
            {"厦门","101230201"},{"广州","101280101"},{"深圳","101280601"},{"南宁","101300101"},
            {"海口","101310101"},{"成都","101270101"},{"贵阳","101260101"},{"昆明","101290101"},
            {"拉萨","101140101"},{"乌鲁木齐","101130101"},{"银川","101170101"},{"西宁","101150101"},
            {"兰州","101160101"},{"青岛","101120201"},{"苏州","101190401"},{"三亚","101310201"},
            {"大连","101070201"},{"宁波","101210401"},{"温州","101210701"},{"桂林","101300501"},
            {"大理","101290201"},{"丽江","101291401"},{"珠海","101280701"},{"佛山","101280800"},
        };
        for (String[] e : m) if (zh.contains(e[0])) return e[1];
        return null;
    }

    static String httpRef(String url, String referer, boolean shortTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(shortTimeout ? 8000 : TIMEOUT);
        c.setReadTimeout(shortTimeout ? 12000 : TIMEOUT);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) YunjianHotelAgent/3.0");
        if (referer != null) c.setRequestProperty("Referer", referer);
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                String l;
                while ((l = br.readLine()) != null) sb.append(l);
            }
        }
        if (code >= 400) throw new Exception("HTTP " + code);
        return sb.toString();
    }

    /** 中国天气网：实况 + 今日气温（失败返回 null） */
    static String weatherCn(String city, String code) {
        try {
            String sk = httpRef("http://d1.weather.com.cn/sk_2d/" + code + ".html",
                    "http://www.weather.com.cn/", true);
            int p = sk.indexOf("var dataSK=");
            JSONObject w = null;
            if (p >= 0) {
                String js = sk.substring(p + "var dataSK=".length()).trim();
                int end = js.indexOf(';');
                if (end > 0) js = js.substring(0, end);
                w = new JSONObject(js);
            }
            String dz = httpRef("http://d1.weather.com.cn/dingzhi/" + code + ".html",
                    "http://www.weather.com.cn/", true);
            int q = dz.indexOf("var cityDZ" + code);
            JSONObject wi = null;
            if (q >= 0) {
                int brace = dz.indexOf('{', q);
                int close = dz.indexOf("};", brace);
                if (brace >= 0 && close > brace) {
                    String js = dz.substring(brace, close + 1);
                    wi = new JSONObject(js).optJSONObject("weatherinfo");
                }
            }
            if (w == null) return null;
            String cur = w.optString("temp", "");
            String sd = w.optString("SD", "");
            String wd = w.optString("WD", ""), ws = w.optString("WS", "");
            String time = w.optString("time", "");
            String weather = (wi != null ? wi.optString("weather", "") : "");
            if (weather.isEmpty()) weather = w.optString("weather", "");
            String hi = (wi != null ? wi.optString("temp", "") : "");
            String lo = (wi != null ? wi.optString("tempn", "") : "");
            StringBuilder sb = new StringBuilder("今天").append(city);
            if (!weather.isEmpty()) sb.append(weather).append("，");
            if (!cur.isEmpty()) sb.append("当前").append(cur).append("℃，");
            if (!lo.isEmpty() && !hi.isEmpty()) sb.append("气温").append(lo).append("~").append(hi).append("，");
            if (!sd.isEmpty()) sb.append("湿度").append(sd);
            if (!wd.isEmpty()) sb.append("，").append(wd).append(ws);
            if (!time.isEmpty()) sb.append("（").append(time).append("更新）");
            sb.append("。需要我帮您安排出行吗？");
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public static String weather(String city, String ask) {
        // 1) 中国天气网（实时、国内可达）
        String code = cityCode(city);
        if (code != null) {
            String r = weatherCn(city, code);
            if (r != null) {
                if (ask.contains("明天") || ask.contains("后天")) {
                    return r + " 明后天的预报请对我说「搜索 " + city + " 明天天气」，我联网帮您查最新消息～";
                }
                return r;
            }
        }
        // 2) Open-Meteo 兜底（未收录城市）
        try {
            double[] coord = null;
            String py = cityPinyin(city);
            if (py != null) coord = cityCoord(py);
            if (coord == null) {
                try {
                    String g = http("GET", "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(city, "UTF-8") + "&count=1&language=zh&format=json", null, null, true);
                    JSONObject jg = new JSONObject(g);
                    JSONArray ar = jg.optJSONArray("results");
                    if (ar != null && ar.length() > 0) {
                        JSONObject r0 = ar.getJSONObject(0);
                        coord = new double[]{r0.getDouble("latitude"), r0.getDouble("longitude")};
                    }
                } catch (Exception ignored) {}
                if (coord == null) return "抱歉，我不认识这个城市，请说一个主要城市，比如「杭州天气」～";
            }
            double lat = coord[0], lon = coord[1];
            String fc = http("GET", String.format(
                "https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Asia%%2FShanghai&forecast_days=3",
                lat, lon), null, null, true);
            JSONObject j = new JSONObject(fc).getJSONObject("daily");
            JSONArray wc = j.getJSONArray("weather_code"),
                    mx = j.getJSONArray("temperature_2m_max"), mn = j.getJSONArray("temperature_2m_min");
            int start = ask.contains("后天") ? 2 : (ask.contains("明天") ? 1 : 0);
            String[] lab = {"今天", "明天", "后天"};
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < Math.min(3, wc.length()); i++) {
                if (i > start) sb.append("、");
                sb.append(lab[i]).append(city).append(wmo(wc.optInt(i)))
                  .append(String.format("，%.0f~%.0f℃", mn.optDouble(i), mx.optDouble(i)));
            }
            sb.append("。需要我帮您安排出行吗？");
            return sb.toString();
        } catch (Exception e) {
            return "联网天气服务暂时不可用，稍后再问我试试～（或说「搜索 " + city + " 天气」）";
        }
    }

    static String wmo(int code) {
        switch (code) {
            case 0: return "晴"; case 1: return "大致晴朗"; case 2: return "多云"; case 3: return "阴";
            case 45: return "雾"; case 48: return "雾凇"; case 51: return "小毛毛雨"; case 53: return "毛毛雨";
            case 55: return "大毛毛雨"; case 61: return "小雨"; case 63: return "中雨"; case 65: return "大雨";
            case 66: return "冻雨"; case 67: return "强冻雨"; case 71: return "小雪"; case 73: return "中雪";
            case 75: return "大雪"; case 77: return "雪粒"; case 80: return "小阵雨"; case 81: return "阵雨";
            case 82: return "强阵雨"; case 85: return "小阵雪"; case 86: return "阵雪"; case 95: return "雷暴";
            case 96: return "雷暴伴冰雹"; case 99: return "雷暴伴大冰雹"; default: return "天气变化";
        }
    }

    // ---------------- 必应搜索 ----------------
    public static String search(String q) {
        try {
            String url = "https://cn.bing.com/search?q=" + URLEncoder.encode(q, "UTF-8") + "&setlang=zh-hans";
            String html = http("GET", url, null, null, false);
            Pattern li = Pattern.compile("<li class=\"b_algo\".*?</li>", Pattern.DOTALL);
            Pattern h2 = Pattern.compile("<h2[^>]*><a[^>]*>(.*?)</a>", Pattern.DOTALL);
            Pattern sn = Pattern.compile("<p[^>]*>(.*?)</p>", Pattern.DOTALL);
            Matcher m = li.matcher(html);
            StringBuilder sb = new StringBuilder("我帮您在网络上查到：");
            int n = 0;
            while (m.find() && n < 3) {
                String block = m.group();
                Matcher hm = h2.matcher(block);
                if (!hm.find()) continue;
                String title = strip(hm.group(1));
                String snip = "";
                Matcher sm = sn.matcher(block);
                if (sm.find()) snip = strip(sm.group(1));
                if (snip.length() > 90) snip = snip.substring(0, 90);
                sb.append("\n").append(n + 1).append(". ").append(title);
                if (!snip.isEmpty()) sb.append(" —— ").append(snip);
                n++;
            }
            if (n == 0) return null;
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
    static String strip(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]+>", "").replaceAll("&nbsp;", " ").replaceAll("\\s+", " ").trim();
    }
}
