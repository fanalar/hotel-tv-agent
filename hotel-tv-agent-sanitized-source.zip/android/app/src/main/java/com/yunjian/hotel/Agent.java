package com.yunjian.hotel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 智能体逻辑：意图识别 + 分发（移植自 Python 后端） */
public final class Agent {

    public static class Resp {
        public String reply = "";
        public String action = "chat";   // chat|switch|checkout_done|mic_off|mic_on|privacy|story|sleep_scene|device|kb|dialect|weather|search
        public String switchTo = null;
        public LinkedHashMap<String, Map<String, Object>> devices = null;
        public String story = null;
        public List<String[]> sources = null;
        public String voice = null;
    }

    // ---------------- 工具 ----------------
    private static String s(String t) { return t.replaceAll("[\\s，。！？、；：“”‘’（）【】《》,.!?;:()\\[\\]·\\-—~～]", ""); }
    public static boolean has(String text, String... words) {
        String t = s(text);
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }
    private static String pname(String pid) { for (String[] p : C.PERSONAS) if (p[0].equals(pid)) return p[1]; return "管家"; }
    private static String tag(String pid)  { for (String[] p : C.PERSONAS) if (p[0].equals(pid)) return p[2]; return ""; }
    private static String psys(String pid) { for (String[] p : C.PERSONAS) if (p[0].equals(pid)) return p[4]; return ""; }
    private static String pvoice(String pid) { for (String[] p : C.PERSONAS) if (p[0].equals(pid)) return p[3]; return "female"; }

    static String chatLLM(JSONArray msgs, String base, String model, String key, int maxTok) {
        try { return Net.chatWithFallback(base, key, msgs, maxTok); }
        catch (Exception e) { return null; }
    }
    static JSONObject m(String role, String content) {
        try { return new JSONObject().put("role", role).put("content", content); }
        catch (Exception e) { return new JSONObject(); }
    }

    // ---------------- 设备指令 ----------------
    public static String deviceCmd(String text) {
        String t = s(text);
        String[][] kw = {
            {"light_on", "开灯", "打开灯", "开下灯", "亮灯"},
            {"light_off", "关灯", "关闭灯", "把灯关"},
            {"ac_on", "空调开", "开空调", "空调制冷", "空调冷"},
            {"ac_off", "关空调", "空调关"},
            {"curtain_open", "开窗帘", "打开窗帘", "拉开窗帘", "窗帘开"},
            {"curtain_close", "关窗帘", "拉上窗帘", "关上窗帘", "窗帘关"},
            {"tv_off", "关电视", "电视关"},
            {"tv_on", "开电视", "打开电视", "电视开"},
            {"sleep", "睡眠模式", "睡前模式", "晚安模式", "睡觉模式"},
            {"volume_up", "音量调大", "声音大点", "大声"},
            {"volume_down", "音量调小", "声音小点", "小声"},
            {"channel_news", "新闻联播", "新闻频道", "看新闻", "听新闻"},
        };
        for (String[] r : kw) {
            for (int i = 1; i < r.length; i++) {
                if (t.contains(r[i])) return r[0];
            }
        }
        if (Pattern.compile("空调.{0,6}\\d{1,2}").matcher(t).find()) return "ac_temp";
        if (Pattern.compile("(灯|亮度).{0,6}\\d{1,3}").matcher(t).find()) return "light_dim";
        if (Pattern.compile("窗帘.{0,6}\\d{1,3}").matcher(t).find()) return "curtain_pct";
        return null;
    }

    // ---------------- 意图 ----------------
    public static String classify(String text) {
        String t = s(text);
        if (has(t, "我要退房", "退房", "清除数据", "清空聊天", "清空数据", "删除记录", "保护隐私", "麦克风")) return "checkout";
        if (has(t, "粤语", "广东话")) return "dialect_yue";
        if (has(t, "四川话")) return "dialect_sichuan";
        if (has(t, "晚安", "讲故事", "故事", "哄睡", "睡觉了", "睡吧", "睡前")) return "story";
        if (deviceCmd(text) != null) return "device";
        if (has(t, "天气", "气温", "下雨", "台风", "多少度", "几度", "冷不冷", "热不冷", "会不会下")) return "weather";
        if (has(t, "附近", "推荐", "好吃", "好玩", "怎么去", "几点", "有没有", "早餐", "退房时间",
                "健身房", "游泳", "泳池", "酒廊", "送餐", "点餐", "洗衣", "wifi", "无线", "密码",
                "机场", "打车", "停车", "西湖", "景点", "餐厅", "美食", "饭店", "酒店", "哪里", "如何",
                "介绍", "开放")) return "kb";
        if (has(t, "搜索", "搜一下", "查一下", "查一查", "查查", "最新", "热点", "实时", "新闻",
                "发生了什么", "网上", "百度一下")) return "search";
        if (has(t, "我想让小姐姐", "我想让小哥哥", "换小姐姐", "换小哥哥", "换小暖", "换阿哲",
                "换个美女", "换个帅哥", "让小姐姐陪我", "让小哥哥陪我")) return "switch";
        return "chat";
    }

    public static String detectPersona(String text) {
        String t = s(text);
        if (has(t, "小暖", "小姐姐", "美女", "姐姐", "温柔")) return "xiaonuan";
        if (has(t, "阿哲", "小哥哥", "帅哥", "哥哥", "儒雅")) return "azhe";
        return null;
    }

    // ---------------- 设备执行 ----------------
    static String execDevice(LinkedHashMap<String, Map<String, Object>> d, String cmd, int num) {
        @SuppressWarnings("unchecked")
        Map<String, Object> light = (Map<String, Object>) d.get("light");
        Map<String, Object> ac = d.get("ac"), cur = d.get("curtain"), tv = d.get("tv");
        int v;
        switch (cmd == null ? "tv_on" : cmd) {
            case "light_on": light.put("on", true); light.put("brightness", Math.max((Integer) light.get("brightness"), 60)); return "好嘞，房间灯光已打开。";
            case "light_off": light.put("on", false); return "好的，灯光已关闭，需要时喊我一声就行。";
            case "light_dim": v = Math.max(1, Math.min(100, num)); light.put("on", true); light.put("brightness", v); return "灯光亮度已调到 " + v + "%。";
            case "ac_on": ac.put("on", true); return "空调已开启，正在为您调节室温。";
            case "ac_off": ac.put("on", false); return "空调已关闭。";
            case "ac_temp": v = Math.max(16, Math.min(30, num)); ac.put("on", true); ac.put("temp", v); return "好的，空调已调到 " + v + "℃ 制冷模式。";
            case "curtain_open": cur.put("open", 100); return "窗帘已为您拉开，外面的夜景很美哦。";
            case "curtain_close": cur.put("open", 0); return "窗帘已拉上，需要私密空间时随时喊我。";
            case "curtain_pct": v = Math.max(0, Math.min(100, num)); cur.put("open", v); return "窗帘已开到 " + v + "%。";
            case "tv_off": tv.put("on", false); return "电视已关闭。";
            case "tv_on": tv.put("on", true); return "电视已打开，当前是直播频道。";
            case "volume_up": v = Math.min(100, (Integer) tv.get("volume") + 10); tv.put("volume", v); return "音量已调大到 " + v + "。";
            case "volume_down": v = Math.max(0, (Integer) tv.get("volume") - 10); tv.put("volume", v); return "音量已调小到 " + v + "。";
            case "channel_news": tv.put("on", true); tv.put("channel", "央视·新闻联播"); return "好的，已为您切换到新闻联播频道。";
            case "sleep": light.put("on", true); light.put("brightness", 18); tv.put("volume", 6);
                cur.put("open", 0); ac.put("on", true); ac.put("temp", 26);
                return "已为您开启睡前模式：灯光调暗、窗帘拉上、音量调低，空调保持26℃，安心休息吧，晚安～";
            default: return "好的，已处理。";
        }
    }

    // ---------------- 知识库检索 ----------------
    static List<String[]> kbSearch(List<String[]> kb, String q, int top) {
        String t = s(q);
        List<String[]> scored = new ArrayList<>();
        for (String[] e : kb) {
            int sc = 0;
            for (int i = 0; i + 2 <= e[0].length(); i++) if (t.contains(e[0].substring(i, i + 2))) sc += 3;
            for (int i = 0; i + 2 <= e[1].length(); i++) if (t.contains(e[1].substring(i, i + 2))) sc += 1;
            for (int i = 0; i < e[0].length(); i++) if (t.contains(String.valueOf(e[0].charAt(i)))) sc += 1;
            if (sc > 0) scored.add(new String[]{sc + "", e[0], e[1]});
        }
        scored.sort((a, b) -> Integer.parseInt(b[0]) - Integer.parseInt(a[0]));
        List<String[]> out = new ArrayList<>();
        for (int i = 0; i < Math.min(top, scored.size()); i++) out.add(new String[]{scored.get(i)[1], scored.get(i)[2]});
        return out;
    }

    // ================================================================
    /** 主入口（子线程调用，可能联网） */
    public static Resp handle(String text, String persona, List<String[]> kb,
                              LinkedHashMap<String, Map<String, Object>> devices,
                              JSONArray history, String base, String model, String key,
                              String defaultCity) {
        Resp r = new Resp();
        r.voice = pvoice(persona);
        boolean wantStory = has(text, "晚安", "故事", "哄睡", "讲故事");

        // 1) 切换人物（提到其他管家名字）
        String target = detectPersona(text);
        if (target != null && !target.equals(persona)) {
            r.switchTo = target; r.voice = pvoice(target);
            if (wantStory) {
                String st = genStory(target, text, base, model, key);
                r.reply = st; r.story = st; r.action = "story";
                return r;
            }
            r.reply = "你好呀，我是" + pname(target) + "，" + tag(target) + "。从现在开始由我来陪着你～想聊天、听故事，还是了解酒店？直接吩咐我就行。";
            r.action = "switch";
            return r;
        }

        String intent = classify(text);
        String pn = pname(persona);

        if (intent.equals("dialect_yue")) {
            r.reply = "你好呀，欢迎入住示例酒店！我系" + pn + "啊，今晚想倾偈定系听个古仔呀？";
            r.action = "dialect"; return r;
        }
        if (intent.equals("dialect_sichuan")) {
            r.reply = "你好噻，欢迎入住示例酒店！我是" + pn + "，想摆哈龙门阵，还是听个故事嘛？";
            r.action = "dialect"; return r;
        }
        if (intent.equals("checkout")) {
            boolean isClear = has(text, "退房", "清除", "清空", "删除") && !has(text, "开麦", "关麦", "麦克风开", "麦克风关");
            if (isClear) { r.reply = "已为您办理退房，本房间全部对话与个人数据已清除（退房即清，隐私无忧）。欢迎再次入住示例酒店，再见～"; r.action = "checkout_done"; return r; }
            if (has(text, "关麦", "麦克风关")) { r.reply = "好的，麦克风已关闭，指示灯熄灭；需要我时再打开就好。"; r.action = "mic_off"; return r; }
            if (has(text, "开麦", "麦克风开")) { r.reply = "麦克风已开启，指示灯亮起，我随时待命。"; r.action = "mic_on"; return r; }
            r.reply = "隐私保护说明：您的对话仅保存在本机，退房时对我说「我要退房」即可一键清除全部数据；顶部有麦克风常亮指示灯，敏感信息不会外传。";
            r.action = "privacy"; return r;
        }
        if (intent.equals("story")) {
            String st = genStory(persona, text, base, model, key);
            r.reply = st; r.story = st;
            r.action = has(text, "晚安", "睡觉", "睡吧", "哄睡", "睡前") ? "sleep_scene" : "story";
            return r;
        }
        if (intent.equals("device")) {
            String cmd = deviceCmd(text);
            int num = 0;
            Matcher m = Pattern.compile("(\\d{1,3})").matcher(s(text));
            if (m.find()) num = Integer.parseInt(m.group(1));
            r.reply = execDevice(devices, cmd, num);
            r.action = "device"; r.devices = devices;
            return r;
        }
        if (intent.equals("weather")) {
            String city = defaultCity;
            for (String[] c : C.CITIES) if (text.contains(c[0])) { city = c[0]; break; }
            r.reply = Net.weather(city, text);
            r.action = "weather"; return r;
        }
        if (intent.equals("search")) {
            String q = text.replaceFirst("^(帮我|请|麻烦|你给我|给我|帮忙|搜索一下|搜一下|查一下|查一查|查查|百度一下|上网查|网上查|搜索|查|搜)", "").trim();
            String res = Net.search(q.isEmpty() ? text : q);
            r.reply = res != null ? res : "联网搜索暂时不可用，您可以问我酒店本地信息，比如早餐时间、附近美食、退房政策～";
            r.action = "search"; return r;
        }
        if (intent.equals("kb")) {
            List<String[]> hits = kbSearch(kb, text, 2);
            if (hits.isEmpty()) {
                r.reply = "这个我暂时没有查到呢。您可以问周边景点、美食、酒店设施或服务（比如早餐、退房时间、健身房、WiFi），或者拨分机0问前台～";
                r.action = "kb"; return r;
            }
            StringBuilder ctx = new StringBuilder();
            for (String[] h : hits) ctx.append("【").append(h[0]).append("】").append(h[1]).append("\n");
            JSONArray msgs = new JSONArray();
            msgs.put(m("system", "你是示例酒店的AI礼宾管家" + pn + "。请只依据下面酒店知识库回答客人问题，语气亲切口语化，60字以内；若知识库信息不足，礼貌说明并建议咨询前台。\n\n知识库：\n" + ctx));
            msgs.put(m("user", text));
            String ans = chatLLM(msgs, base, model, key, 160);
            r.reply = ans != null ? ans : hits.get(0)[1] + "（来自酒店知识库：" + hits.get(0)[0] + "）";
            r.action = "kb"; r.sources = hits;
            return r;
        }
        // 默认：情绪陪伴聊天
        JSONArray msgs = new JSONArray();
        msgs.put(m("system", psys(persona)));
        int from = Math.max(0, history.length() - 10);
        for (int i = from; i < history.length(); i++) {
            try { msgs.put(history.getJSONObject(i)); } catch (Exception ignored) {}
        }
        msgs.put(m("user", text));
        String ans = chatLLM(msgs, base, model, key, 160);
        r.reply = ans != null ? ans : fallback(persona, text);
        return r;
    }

    static String genStory(String persona, String text, String base, String model, String key) {
        JSONArray msgs = new JSONArray();
        msgs.put(m("system", "你是" + pname(persona) + "，请为酒店客人创作一个温柔治愈的睡前晚安故事。要求：150~230字、中文、适合睡前听、结尾有晚安祝福。直接输出故事正文。"));
        msgs.put(m("user", text));
        String ans = chatLLM(msgs, base, model, key, 600);
        return (ans != null && ans.length() > 10) ? ans : C.STORY_FALLBACK;
    }

    static String fallback(String persona, String text) {
        String n = pname(persona);
        if (has(text, "你好", "在吗")) return "你好呀，我是" + n + "，很高兴陪着你。想聊聊天、听故事，还是了解酒店服务？直接跟我说就行～";
        if (has(text, "谢谢")) return "不客气～能帮到你我很开心。";
        if (has(text, "累", "烦", "难过", "压力")) return "辛苦啦，先深呼吸一下。你现在安全地在房间里，我就在这里陪着你。要不要我给你讲个轻松的小故事，或者把灯光调成暖暖的？";
        if (has(text, "名字")) return "我叫" + n + "，是示例酒店的AI管家，负责陪你聊聊天、管理房间设备、解答酒店问题～";
        return "我在呢，我是" + n + "。你可以跟我说「开灯」「空调调到26度」「附近有什么好吃的」「讲个晚安故事」「我要退房」等，我都能听懂哦。";
    }
}
