package com.yunjian.hotel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 常量：人格 / 知识库 / 城市 / 新闻 / WMO */
public final class C {
    private C() {}

    public static final String HOTEL = "示例酒店";

    // ---------- DeepSeek 默认（App 设置里可改） ----------
    public static final String DEF_BASE = "https://api.deepseek.com/v1";
    public static final String DEF_MODEL = "deepseek-v4-flash";
    public static final String DEF_KEY = ""; // 占位，由打包脚本注入真实 key

    // ---------- 人格 ----------
    public static final String[][] PERSONAS = {
        {"xiaonuan", "小暖", "温柔管家 · 小姐姐", "female",
         "你是示例酒店客房里的 AI 陪伴管家「小暖」，一个温柔体贴、声音甜美的姐姐型管家。你负责陪客人聊天、提供情绪价值、讲晚安故事、回答酒店与本地旅游问题。语气温暖有耐心、口语化、适度关心，回复简洁（一般不超过80字，除非用户要求讲故事或长内容）。"},
        {"azhe", "阿哲", "儒雅管家 · 小哥哥", "male",
         "你是示例酒店客房里的 AI 陪伴管家「阿哲」，一个儒雅稳重又不失幽默的哥哥型管家。你负责陪客人聊天、提供情绪价值、讲晚安故事、回答酒店与本地旅游问题。语气礼貌大方、略带幽默感、口语化，回复简洁（一般不超过80字，除非用户要求讲故事或长内容）。"},
    };

    public static final String STORY_FALLBACK =
        "今晚讲一个《月亮上的小兔子》的故事。\n\n从前，月亮上住着一只毛茸茸的小兔子，它每晚都会用云朵做一张软软的床，然后数着星星入睡。有一晚，一阵风吹来，把它的云朵床吹散了一角。小兔子有点难过，星星们看见了，纷纷眨着眼睛说：「别担心，我们用光给你缝起来。」于是星星们把银光一缕缕织进云朵里，床变得更软更亮了。小兔子躺上去，闻到了月亮桂花的香气，很快就睡着了，嘴角还带着甜甜的笑。\n\n晚安，愿你今晚也像小兔子一样，枕着星光，做个好梦。";

    public static final String[] NEWS = {
        "杭州明日多云 22~28℃，适宜出行",
        "西湖景区周末客流较大，建议错峰游览",
        "示例酒店行政酒廊今晚 19:00 现场爵士演出",
        "客房送餐服务延长至 23:30",
        "欢迎入住示例酒店，我是您的AI管家小暖/阿哲",
        "演示频道·高清 直播中 · 频道008",
    };

    // ---------- 城市拼音表 ----------
    public static final String[][] CITIES = {
        {"北京","beijing"},{"上海","shanghai"},{"广州","guangzhou"},{"深圳","shenzhen"},
        {"杭州","hangzhou"},{"成都","chengdu"},{"重庆","chongqing"},{"武汉","wuhan"},
        {"西安","xian"},{"南京","nanjing"},{"天津","tianjin"},{"苏州","suzhou"},
        {"长沙","changsha"},{"青岛","qingdao"},{"厦门","xiamen"},{"昆明","kunming"},
        {"三亚","sanya"},{"哈尔滨","haerbin"},{"乌鲁木齐","wulumuqi"},{"拉萨","lasa"},
    };

    // ---------- 设备默认 ----------
    public static LinkedHashMap<String, Map<String, Object>> defaultDevices() {
        LinkedHashMap<String, Map<String, Object>> d = new LinkedHashMap<>();
        d.put("light", v("label", "灯光", "on", false, "brightness", 80));
        d.put("ac", v("label", "空调", "on", false, "temp", 26));
        d.put("curtain", v("label", "窗帘", "open", 100));
        d.put("tv", v("label", "电视", "on", true, "volume", 30, "channel", "演示频道·高清 008"));
        return d;
    }
    private static Map<String, Object> v(Object... kv) {
        Map<String, Object> m = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (kv[i] instanceof String) m.put((String) kv[i], kv[i + 1]);
            else m.put(String.valueOf(kv[i]), kv[i + 1]);  // 防御：非字符串键转字符串
        }
        return m;
    }

    // ---------- 知识库 ----------
    public static String[][] kbSeed() {
        return new String[][]{
            {"退房时间", "退房时间为中午12:00前。如需延迟退房可致电前台（分机0），视房态可延至14:00。退房时对我说「我要退房」即可清除本房间所有对话数据。"},
            {"早餐服务", "早餐供应时间 6:30-10:00，位于一楼「云间餐厅」，报房号即可。中式西式都有，推荐本店特色奶皮子酸奶。"},
            {"健身房", "健身房位于3层，24小时开放，刷房卡进入，提供毛巾与饮用水。"},
            {"游泳池", "室内恒温泳池位于3层，开放时间 7:00-22:00，请携带房卡登记。"},
            {"行政酒廊", "行政酒廊位于顶层，今晚19:00有现场爵士演出，住行政楼层的客人可凭房卡免费进入。"},
            {"客房送餐", "客房送餐服务延长至23:30，点餐可拨分机 1 或对我说「我要点餐」。"},
            {"洗衣服务", "洗衣服务：当天18:00前送洗，次日10:00前送回，填写洗衣单放门内袋中即可，详情分机 2。"},
            {"WiFi", "全酒店免费WiFi：连接「Yunjian-Hotel」，账号为您的房间号，密码为入住时前台提供的六位数字（或房卡背面）。"},
            {"机场交通", "距萧山国际机场约35公里，打车约40分钟、费用120元左右；也可在酒店门口坐机场大巴，约50分钟。"},
            {"西湖", "西湖距酒店约3公里，打车10分钟或步行20分钟。推荐傍晚去苏堤散步、看音乐喷泉（每晚19:30/20:30各一场）。"},
            {"本地美食推荐", "周边推荐：楼外楼（西湖醋鱼、叫花鸡）、绿茶餐厅（面包诱惑）、奎元馆（片儿川面）。想吃夜宵可让送餐送到房间。"},
            {"周边娱乐", "附近有银泰百货、湖滨银泰in77购物中心，步行15分钟；杭州大剧院常有演出，可帮您查询场次。"},
            {"客房服务", "客房服务需求（加被子、换牙刷、打扫）可直接对我说，或拨分机 3，我们会尽快为您安排。"},
            {"停车", "酒店地下停车场24小时开放，住店客人免费停车，电梯直达客房楼层。"},
            {"酒店介绍", "欢迎入住示例酒店！这里提供智能客房、24小时健身、恒温泳池与行政酒廊。我是您的AI管家，可以陪您聊天、讲故事，也可以帮您控制房间灯光空调窗帘，想了解什么随时问我。"},
        };
    }

    public static final String[] WELCOME_CHIPS = {"我想让小姐姐陪我", "我想让小哥哥陪我"};
    public static final String[] STAGE_CHIPS = {
        "讲个晚安故事", "杭州明天天气怎么样", "附近有什么好吃的", "把空调调到26度",
        "拉上窗帘", "用粤语打个招呼", "开灯", "我要退房"};
    public static final String[] PANEL_LABELS = {"🎛️ 设备", "🏨 知识库", "🔒 隐私", "⌨️ 文字"};
}
