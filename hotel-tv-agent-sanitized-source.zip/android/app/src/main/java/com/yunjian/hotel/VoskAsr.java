package com.yunjian.hotel;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.util.concurrent.atomic.AtomicBoolean;

/** 离线语音识别（Vosk 中文模型，不依赖系统语音服务） */
public class VoskAsr {

    public interface Callback {
        void onPartial(String text);
        void onFinal(String text);
        void onError(String msg);
    }

    private final Model model;
    private final Callback cb;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread thread;

    public VoskAsr(Model model, Callback cb) {
        this.model = model;
        this.cb = cb;
    }

    public void start() {
        if (running.getAndSet(true)) return;
        thread = new Thread(() -> {
            AudioRecord recorder = null;
            try {
                int min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                int bufSize = Math.max(min, 3200);
                recorder = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
                recorder.startRecording();
                byte[] buf = new byte[bufSize];
                while (running.get()) {
                    Recognizer rec = new Recognizer(model, 16000.0f);
                    boolean ended = false;
                    while (running.get() && !ended) {
                        int n = recorder.read(buf, 0, buf.length);
                        if (n < 0) { throw new RuntimeException("mic read error"); }
                        if (n == 0) continue;
                        boolean fin = rec.acceptWaveForm(buf, n);
                        if (fin) {
                            String text = new JSONObject(rec.getResult()).optString("text", "").trim();
                            if (!text.isEmpty()) {
                                cb.onFinal(text);
                                ended = true;
                            }
                        } else {
                            String p = new JSONObject(rec.getPartialResult()).optString("partial", "").trim();
                            if (!p.isEmpty()) cb.onPartial(p);
                        }
                    }
                    rec.close();
                }
            } catch (Throwable t) {
                if (running.get()) cb.onError(t.getClass().getSimpleName() + ": " + (t.getMessage() == null ? "" : t.getMessage()));
            } finally {
                running.set(false);
                if (recorder != null) {
                    try { recorder.stop(); } catch (Throwable ignored) {}
                    try { recorder.release(); } catch (Throwable ignored) {}
                }
            }
        }, "vosk-asr");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running.set(false);
        try {
            if (thread != null) thread.interrupt();
        } catch (Throwable ignored) {}
        thread = null;
    }
}
