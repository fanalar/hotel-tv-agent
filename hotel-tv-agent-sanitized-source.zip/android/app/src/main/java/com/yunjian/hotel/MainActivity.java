package com.yunjian.hotel;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.vosk.LibVosk;
import org.vosk.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 示例酒店 AI 管家 · 独立版（原生安卓，不依赖电脑） */
public class MainActivity extends Activity {

    private static final int REQ_MIC = 1001;
    private static final int REQ_ALL = 1002;
    private static final int REQ_SPEECH = 2001;

    // ---------- 状态 ----------
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private String persona = "xiaonuan";
    private int phase = 0; // 0 welcome 1 stage
    private boolean micOn = true, busy = false;
    private String curCity = "杭州";
    private int speechErrCount = 0;
    private boolean speechContinuous = true;   // 连续识别；失败后切系统语音框
    private boolean intentLaunched = false;
    private Model voskModel;
    private VoskAsr voskAsr;
    private boolean voskReady = false;
    private boolean voskLoadFailed = false;
    private boolean loadRetryScheduled = false;
    private int micErrCount = 0;
    private LinkedHashMapBox devicesBox;
    private java.util.LinkedHashMap<String, Map<String, Object>> devices;
    private List<String[]> kb;
    private final JSONArray hist = new JSONArray();
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private SharedPreferences prefs;
    private String base, model, apiKey;

    // ---------- UI ----------
    private LinearLayout root, welcomeView, stageView, contentFrame;
    private FrameLayout stageWrap;
    private TextView ledTxt, hintBar, newsTv, aiLine, userLine, listenRow, nameTag, topTitle, topSub;
    private CircleIv avatar;
    private View micLedDot;
    private ImageView stageAvatarIv;
    private LinearLayout chipsRow;
    private ValueAnimator breathAnim;
    private View overlayDim;
    private String[] storyPlaying;

    private static class LinkedHashMapBox {
        java.util.LinkedHashMap<String, Map<String, Object>> v;
        LinkedHashMapBox(java.util.LinkedHashMap<String, Map<String, Object>> v) { this.v = v; }
    }

    // ================================================================ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try { recordCrash(e); } catch (Throwable ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
        });
        runStartup();
    }

    /** 分阶段初始化：失败即弹出「哪一步+完整堆栈+复制」对话框，便于定位 */
    private void runStartup() {
        try { stage("窗口初始化", () -> {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            hideUi();
        }); } catch (Throwable t) { fail("窗口初始化", t); return; }

        try { stage("配置读取", () -> {
            prefs = getSharedPreferences("yunjian_v2", MODE_PRIVATE);
            base = prefs.getString("base", C.DEF_BASE);
            model = prefs.getString("model", C.DEF_MODEL);
            apiKey = LocalSecrets.load(prefs);
            devices = C.defaultDevices();
            kb = new ArrayList<>();
            for (String[] e : C.kbSeed()) kb.add(new String[]{e[0], e[1]});
        }); } catch (Throwable t) { fail("配置读取", t); return; }

        try { stage("界面构建", this::buildUi); } catch (Throwable t) { fail("界面构建", t); return; }

        try { stage("语音合成初始化", () -> {
            tts = new TextToSpeech(this, s -> {
                if (s == TextToSpeech.SUCCESS) {
                    try {
                        int r = tts.setLanguage(Locale.CHINA);
                        tts.setSpeechRate(1.0f);
                        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            public void onStart(String u) { ui.post(() -> setSpeakingAnim(true)); }
                            public void onDone(String u) { ui.post(() -> setSpeakingAnim(false)); }
                            public void onError(String u) { ui.post(() -> setSpeakingAnim(false)); }
                        });
                    } catch (Throwable ignored) {}
                }
            });
        }); } catch (Throwable t) { fail("语音合成初始化", t); }

        // 离线语音模型（独立线程加载，带进度与超时，不阻塞任何业务）
        final String[] stage = {"解压模型…"};
        listenState("语音引擎加载中·" + stage[0]);
        new Thread(() -> {
            try {
                java.io.File modelDir = new java.io.File(getFilesDir(), "vosk-model-cn");
                if (!new java.io.File(modelDir, "am/final.mdl").exists()) {
                    copyAssets("vosk-model-cn", modelDir);
                }
                stage[0] = "初始化引擎…";
                ui.post(() -> listenState("语音引擎加载中·" + stage[0]));
                // 保险：显式注册 native 库搜索路径 + 预载 JNA dispatch（JNA 兼容性兜底）
                try {
                    System.loadLibrary("jnidispatch");
                } catch (Throwable ignored) {}
                try {
                    com.sun.jna.NativeLibrary.addSearchPath("vosk", getApplicationInfo().nativeLibraryDir);
                } catch (Throwable ignored) {}
                voskModel = new Model(modelDir.getAbsolutePath());
                ui.post(() -> {
                    voskReady = true;
                    listenState("正在聆听…请说话");
                    try { toast("离线语音识别已就绪"); } catch (Throwable ignored) {}
                    startListening();
                });
            } catch (Throwable t) {
                final String msg = (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
                ui.post(() -> {
                    voskLoadFailed = true;
                    toast("离线语音引擎加载失败：" + (msg.length() > 60 ? msg.substring(0, 60) : msg));
                    listenState("离线语音不可用，请用 ⌨️ 文字输入");
                });
            }
        }, "vosk-loader").start();
        // 看门狗：90 秒仍未就绪则视为失败（避免永久"加载中"）
        ui.postDelayed(() -> {
            if (!voskReady && !voskLoadFailed) {
                voskLoadFailed = true;
                toast("语音引擎加载超时，请重启应用重试；期间可用 ⌨️ 文字输入");
                listenState("离线语音不可用，请用 ⌨️ 文字输入");
            }
        }, 90000);

        // 延迟到首帧后：规避部分机型在 onCreate 内请求权限/焦点导致的时序问题
        ui.post(() -> {
            try { askPermissionsAndStart(); } catch (Throwable t) { fail("麦克风初始化", t); }
            try { runNews(); } catch (Throwable t) { fail("新闻初始化", t); }
        });
    }

    /** 递归复制 assets 目录到 files 目录 */
    private void copyAssets(String path, java.io.File dest) throws Exception {
        String[] list = getAssets().list(path);
        if (list == null || list.length == 0) return;
        dest.mkdirs();
        for (String name : list) {
            String sub = path + "/" + name;
            String[] subList = getAssets().list(sub);
            if (subList != null && subList.length > 0) {
                copyAssets(sub, new java.io.File(dest, name));
            } else {
                java.io.File out = new java.io.File(dest, name);
                try (java.io.InputStream in = getAssets().open(sub);
                     java.io.FileOutputStream os = new java.io.FileOutputStream(out)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
        }
    }

    private interface S0 { void run() throws Throwable; }
    private void stage(String name, S0 fn) throws Throwable { fn.run(); }

    /** 弹窗显示 失败阶段 + 完整堆栈，并复制到剪贴板 */
    private void fail(String stageName, Throwable t) {
        try { recordCrash(t); } catch (Throwable ignored) {}
        StringBuilder sb = new StringBuilder();
        sb.append("阶段：").append(stageName).append("\n");
        sb.append(t.toString()).append("\n");
        for (StackTraceElement e : t.getStackTrace()) sb.append("  at ").append(e.toString()).append("\n");
        if (t.getCause() != null) {
            sb.append("Caused by: ").append(t.getCause()).append("\n");
            for (StackTraceElement e : t.getCause().getStackTrace()) sb.append("  at ").append(e.toString()).append("\n");
        }
        final String detail = sb.toString();
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", detail));
        } catch (Throwable ignored) {}
        try {
            TextView v = new TextView(this);
            v.setText(detail);
            v.setTextSize(11);
            v.setPadding(dp(16), dp(8), dp(16), dp(8));
            ScrollView sv = new ScrollView(this);
            sv.addView(v);
            AlertDialog.Builder d = new AlertDialog.Builder(this);
            d.setTitle("初始化失败：" + stageName + "（已复制，可发给开发者）");
            d.setView(sv);
            d.setPositiveButton("复制成功，我知道了", null);
            d.show();
        } catch (Throwable ignored) {}
    }

    private void recordCrash(Throwable t) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("=== ").append(new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.CHINA).format(new java.util.Date())).append(" ===\n");
            sb.append(t.toString()).append("\n");
            for (StackTraceElement e : t.getStackTrace()) sb.append("  at ").append(e.toString()).append("\n");
            if (t.getCause() != null) { sb.append("Caused by: ").append(t.getCause()).append("\n");
                for (StackTraceElement e : t.getCause().getStackTrace()) sb.append("  at ").append(e.toString()).append("\n"); }
            java.io.File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            java.io.File f = new java.io.File(dir, "crash.log");
            try (java.io.FileWriter w = new java.io.FileWriter(f, true)) { w.write(sb.toString()); }
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onResume() { super.onResume(); hideUi(); }

    @Override
    public void onBackPressed() {
        if (storyOverlayShown) closeStoryOverlay();
        else super.onBackPressed();
    }
    private boolean storyOverlayShown = false;

    private void askPermissionsAndStart() {
        java.util.ArrayList<String> need = new java.util.ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_ALL);
        else { startListening(); getLocation(); }
    }
    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] g) {
        if (c != REQ_ALL) return;
        boolean mic = true, loc = true;
        for (int i = 0; i < p.length; i++) {
            boolean ok = g[i] == PackageManager.PERMISSION_GRANTED;
            if (Manifest.permission.RECORD_AUDIO.equals(p[i])) mic = ok;
            if (Manifest.permission.ACCESS_FINE_LOCATION.equals(p[i]) || Manifest.permission.ACCESS_COARSE_LOCATION.equals(p[i])) loc = ok;
        }
        if (mic) startListening(); else toast("未授权麦克风，可用 ⌨️ 文字输入");
        if (loc) getLocation(); else toast("未授权定位，天气将默认使用杭州（可在问题里直接说城市名）");
    }

    // ================================================================ 定位
    private void getLocation() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm == null) return;
            Location loc = null;
            try { loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER); } catch (Throwable ignored) {}
            if (loc == null) try { loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); } catch (Throwable ignored) {}
            if (loc != null) { onLocationGot(loc); return; }
            final LocationListener ll = new LocationListener() {
                public void onLocationChanged(Location l) { onLocationGot(l); }
                public void onStatusChanged(String provider, int status, android.os.Bundle extras) {}
                public void onProviderEnabled(String provider) {}
                public void onProviderDisabled(String provider) {}
            };
            try { lm.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, ll, Looper.getMainLooper()); } catch (Throwable ignored) {}
        } catch (Throwable ignored) {}
    }
    private void onLocationGot(Location loc) {
        final double lat = loc.getLatitude(), lon = loc.getLongitude();
        exec.execute(() -> {
            String city = Net.reverseCity(lat, lon);
            ui.post(() -> {
                if (city != null && !city.isEmpty()) {
                    curCity = city;
                    toast("已定位到：" + city);
                }
            });
        });
    }

    // ================================================================ 语音
    private void startListening() {
        if (!micOn || busy || intentLaunched) return;
        stopRec();
        // 优先：离线 Vosk 识别（不依赖系统语音服务）
        if (voskReady && voskModel != null) {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                listenState("请先允许麦克风权限");
                try { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_ALL); } catch (Throwable ignored) {}
                return; // 权限回调后会重新 startListening
            }
            listenState("正在聆听…请说话");
            voskAsr = new VoskAsr(voskModel, new VoskAsr.Callback() {
                public void onPartial(String t) { ui.post(() -> listenState(t.isEmpty() ? "正在聆听…" : "（" + t + "）")); }
                public void onFinal(String t) { ui.post(() -> handleText(t)); }
                public void onError(String m) {
                    ui.post(() -> {
                        if (m != null && (m.contains("permission") || m.contains("Security") || m.contains("RECORD"))) {
                            setMic(false, "麦克风权限未开启，请重新授权后再说话");
                            return;
                        }
                        micErrCount++;
                        if (micErrCount >= 3) {
                            voskReady = false; voskLoadFailed = true;
                            listenState("离线语音不可用，请用 ⌨️ 文字输入");
                            toast("语音识别连续出错：" + m);
                        } else {
                            listenState("语音重试中…");
                            restartListen(1500);
                        }
                    });
                }
            });
            voskAsr.start();
            return;
        }
        // 模型未就绪：安静等待加载，绝不调用系统识别（红米"语音搜索下线"弹窗的源头）
        if (voskLoadFailed) {
            listenState("离线语音不可用，请用 ⌨️ 文字输入");
            return;
        }
        if (!loadRetryScheduled) {
            loadRetryScheduled = true;
            listenState("语音引擎加载中…");
            ui.postDelayed(() -> {
                loadRetryScheduled = false;
                if (!voskReady && micOn && !busy) startListening();
            }, 1500);
        }
    }

    /** 系统级语音输入框兜底（各 ROM 通用）—— v3.2 起不再自动调用（仅保留，防误触发弹窗） */
    private void launchSpeechIntent() {
        try {
            Intent it = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            it.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            it.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN");
            it.putExtra(RecognizerIntent.EXTRA_PROMPT, "请说话…");
            intentLaunched = true;
            listenState("点击麦克风，开始说话…");
            startActivityForResult(it, REQ_SPEECH);
        } catch (Exception e) {
            intentLaunched = false;
            toast("本设备没有可用的语音识别服务，请用 ⌨️ 文字输入");
        }
    }
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SPEECH) {
            intentLaunched = false;
            if (res == RESULT_OK && data != null) {
                ArrayList<String> arr = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (arr != null && !arr.isEmpty()) handleText(arr.get(0));
                else restartListen(600);
            } else restartListen(600);
        }
    }
    private void restartListen(long delay) {
        ui.postDelayed(() -> { if (micOn && !busy) startListening(); }, delay);
    }
    private boolean speechAvailable() {
        try { return SpeechRecognizer.isRecognitionAvailable(this); }
        catch (Throwable t) { return false; }
    }
    private void stopRec() {
        if (voskAsr != null) { voskAsr.stop(); voskAsr = null; }
        if (sr != null) { try { sr.stopListening(); sr.cancel(); } catch (Exception ignored) {} sr = null; }
    }

    private void listenState(String s) {
        if (listenRow == null) return;
        if (s == null) listenRow.setText(busy ? "正在回复…" : (micOn ? "" : "麦克风已关闭"));
        else listenRow.setText(s);
    }

    // ================================================================ 说话/TTS
    private void speak(String text, String voiceGender) {
        if (!ttsReady) return;
        try {
            tts.stop();
            if ("male".equals(voiceGender)) { tts.setPitch(0.82f); }
            else { tts.setPitch(1.08f); }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.currentTimeMillis());
        } catch (Exception ignored) {}
    }
    private void setSpeakingAnim(boolean on) {
        if (avatar == null) return;
        if (on && (breathAnim == null || !breathAnim.isRunning())) {
            breathAnim = ObjectAnimator.ofFloat(avatar, "scaleX", 1f, 1.05f, 1f);
            breathAnim.setDuration(1500); breathAnim.setRepeatCount(ValueAnimator.INFINITE);
            breathAnim.start();
            ObjectAnimator y = ObjectAnimator.ofFloat(avatar, "scaleY", 1f, 1.05f, 1f);
            y.setDuration(1500); y.setRepeatCount(ValueAnimator.INFINITE); y.start();
        } else if (!on && breathAnim != null) { breathAnim.cancel(); avatar.setScaleX(1f); avatar.setScaleY(1f); }
    }

    // ================================================================ 主处理
    private void setUserLine(String t) {
        if (userLine == null) return;
        userLine.setText(t == null || t.isEmpty() ? "" : "你说：" + t);
    }
    private void pushHist(String role, String content) {
        try { hist.put(new JSONObject().put("role", role).put("content", content)); }
        catch (Exception ignored) {}
    }

    private void handleText(String raw) {
        final String text = raw == null ? "" : raw.trim();
        if (text.isEmpty() || busy) return;
        busy = true; listenState("正在回复…"); stopRec();
        if (phase == 0) enterStage(persona);
        setUserLine(text);
        // 「我在哪/我的位置/定位」本地直答（不调模型，秒回）
        if (Agent.has(text, "我在哪", "我的位置", "我在哪里", "位置在哪", "定位")) {
            final String cityNow = curCity;
            ui.post(() -> {
                busy = false;
                pushHist("user", text);
                String rep = "根据定位，您当前在" + cityNow + "。需要我帮您查这里的天气吗？";
                pushHist("assistant", rep);
                typeLine(rep);
                speak(rep, personaVoice());
                restartListen(800);
            });
            return;
        }
        // 「手机助手」面板快捷入口
        if (Agent.has(text, "手机助手", "无障碍", "操控手机")) {
            ui.post(() -> {
                busy = false;
                pushHist("user", text);
                String rep = "已为您打开手机助手面板，在这里一键开启无障碍服务后，就能用语音操控手机啦。";
                pushHist("assistant", rep);
                typeLine(rep);
                speak(rep, personaVoice());
                showPhoneAssistPanel();
                restartListen(800);
            });
            return;
        }
        // 「手机助手」操控指令（返回/桌面/打开应用/音量/亮度/通知栏）
        if (PhoneCmd.isPhoneCommand(text)) {
            ui.post(() -> {
                busy = false;
                pushHist("user", text);
                String rep = PhoneCmd.execute(this, text);
                pushHist("assistant", rep);
                typeLine(rep);
                speak(rep, personaVoice());
                restartListen(800);
            });
            return;
        }
        final String curPersona = persona;
        exec.execute(() -> {
            final Agent.Resp resp = Agent.handle(text, curPersona, kb, devices, hist, base, model, apiKey, curCity);
            ui.post(() -> {
                busy = false;
                pushHist("user", text);
                pushHist("assistant", resp.reply);
                if (hist.length() > 40) { while (hist.length() > 40) hist.remove(0); }
                applyResp(resp);
                restartListen(800);
            });
        });
    }

    private void applyResp(Agent.Resp r) {
        String act = r.action;
        switch (act) {
            case "switch":
                persona = r.switchTo;
                refreshStagePersona();
                break;
            case "checkout_done":
                while (hist.length() > 0) hist.remove(0);
                devices = C.defaultDevices();
                enterWelcome();
                break;
            case "mic_off": setMic(false, "麦克风已关闭"); break;
            case "mic_on": setMic(true, "麦克风已开启"); break;
            case "story": case "sleep_scene": showStory(r.reply, act.equals("sleep_scene")); break;
            case "device": if (r.devices != null) { devices = r.devices; } break;
            case "kb": if (r.sources != null) showKbPanel(r.sources); break;
            default: break;
        }
        typeLine(r.reply);
        speak(r.reply, r.voice == null ? personaVoice() : r.voice);
    }
    private String personaVoice() { for (String[] p : C.PERSONAS) if (p[0].equals(persona)) return p[3]; return "female"; }

    private void typeLine(final String full) {
        aiLine.setText("");
        aiLine.setTextColor(0xFFF2F6FF);
        final int total = full.length();
        new Thread(() -> {
            for (int i = 1; i <= total; i += Math.max(1, total / 60)) {
                final int n = Math.min(i, total);
                ui.post(() -> aiLine.setText(full.substring(0, n)));
                try { Thread.sleep(8); } catch (Exception ignored) {}
            }
        }).start();
    }

    // ================================================================ 阶段切换
    private void enterStage(String pid) { phase = 1; persona = pid;
        welcomeView.setVisibility(View.GONE); stageView.setVisibility(View.VISIBLE);
        refreshStagePersona(); buildChips(); toast("已选择" + pname(pid)); }
    private void enterWelcome() { phase = 0;
        welcomeView.setVisibility(View.VISIBLE); stageView.setVisibility(View.GONE);
        setUserLine(""); aiLine.setText("欢迎入住示例酒店～"); buildChips(); }
    private String pname(String pid) { for (String[] p : C.PERSONAS) if (p[0].equals(pid)) return p[1]; return ""; }

    private void refreshStagePersona() {
        int id = persona.equals("azhe") ? R_drawable_azhe : R_drawable_xiaonuan;
        avatar.setImageResource(id);
        String tag = "";
        for (String[] p : C.PERSONAS) if (p[0].equals(persona)) tag = p[1] + " · " + p[2];
        nameTag.setText(tag);
    }

    // drawable id helper
    private static int R_drawable_azhe = 0, R_drawable_xiaonuan = 0;
    private void initDrawableIds() {
        R_drawable_azhe = getResources().getIdentifier("p_azhe", "drawable", getPackageName());
        R_drawable_xiaonuan = getResources().getIdentifier("p_xiaonuan", "drawable", getPackageName());
        if (R_drawable_xiaonuan == 0) R_drawable_xiaonuan = android.R.drawable.ic_menu_gallery;
        if (R_drawable_azhe == 0) R_drawable_azhe = android.R.drawable.ic_menu_gallery;
    }

    private void setMic(boolean on, String msg) { micOn = on;
        ledTxt.setText(on ? "收音中" : "已静音");
        micLedDot.setBackgroundResource(0);
        micLedDot.getBackground();
        micLedDot.setBackground(on ? dotRed() : dotGray());
        if (on) { startListening(); } else stopRec();
        toast(msg);
    }
    private android.graphics.drawable.GradientDrawable dotRed() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(0xFFE8403F); return d;
    }
    private android.graphics.drawable.GradientDrawable dotGray() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(0xFF55607A); return d;
    }

    // ================================================================ UI 构建
    private void buildUi() {
        initDrawableIds();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        setContentView(root);

        FrameLayout base = new FrameLayout(this);
        base.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        SkyView sky = new SkyView(this);
        base.addView(sky, new FrameLayout.LayoutParams(-1, -1));

        contentFrame = new LinearLayout(this);
        contentFrame.setOrientation(LinearLayout.VERTICAL);
        base.addView(contentFrame, new FrameLayout.LayoutParams(-1, -1));

        // 顶部状态
        LinearLayout top = row();
        top.setPadding(dp(16), dp(10), dp(16), 0);
        contentFrame.addView(top, lpWrap());
        TextView badge5g = tv("5G", 15, 0xFF1E7BFF, Color.WHITE);
        badge5g.setPadding(dp(8), dp(2), dp(8), dp(2));
        badge5g.setBackground(round(8, 0xFFFFFFFF));
        // dark blue badge
        android.graphics.drawable.GradientDrawable bd = round(8, 0xFF1E7BFF);
        badge5g.setBackground(bd);
        top.addView(badge5g);
        LinearLayout brandCol = col();
        top.addView(brandCol);
        topTitle = tv("演示频道 · 高清", 20, 0x000000, Color.WHITE);
        brandCol.addView(topTitle);
        topSub = tv("演示频道·高清 008 · 数字电视", 11, 0x000000, 0xFF9FB3D1);
        brandCol.addView(topSub);
        View sp1 = new View(this); sp1.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        top.addView(sp1);
        LinearLayout right = row(); right.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(right);
        TextView live = tv("● 直播中", 13, 0x000000, Color.WHITE);
        live.setPadding(dp(12), dp(4), dp(12), dp(4));
        live.setBackground(round(20, 0xFFE8403F));
        right.addView(live);
        right.addView(vspace(8));
        micLedDot = new View(this);
        micLedDot.setLayoutParams(new LinearLayout.LayoutParams(dp(10), dp(10)));
        micLedDot.setBackground(dotRed());
        right.addView(micLedDot);
        right.addView(vspace(4));
        ledTxt = tv(micOn ? "收音中" : "已静音", 11, 0x000000, 0xFF9FB3D1);
        right.addView(ledTxt);

        // 提示条
        hintBar = tv("欢迎入住，请选择您的陪伴管家", 14, 0x000000, 0xFFEAF2FF);
        hintBar.setGravity(Gravity.CENTER);
        hintBar.setPadding(dp(18), dp(6), dp(18), dp(6));
        hintBar.setBackground(round(30, 0x1AFFFFFF));
        LinearLayout.LayoutParams hl = lpWrap();
        hl.topMargin = dp(8);
        contentFrame.addView(hintBar, hl);

        // 舞台容器（welcome + stage）
        FrameLayout stageHost = new FrameLayout(this);
        stageHost.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        contentFrame.addView(stageHost);

        welcomeView = buildWelcome();
        stageView = buildStage();
        stageHost.addView(welcomeView, new FrameLayout.LayoutParams(-1, -1));
        stageHost.addView(stageView, new FrameLayout.LayoutParams(-1, -1));
        stageView.setVisibility(View.GONE);

        // chips
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(52)));
        chipsRow = new LinearLayout(this);
        chipsRow.setPadding(dp(14), dp(8), dp(14), dp(8));
        hsv.addView(chipsRow);
        contentFrame.addView(hsv);

        // 底部条: 新闻 + 右侧按钮
        LinearLayout bottomBar = row();
        bottomBar.setPadding(dp(14), dp(6), dp(14), dp(10));
        contentFrame.addView(bottomBar, lpWrap());
        LinearLayout newsWrap = col();
        bottomBar.addView(newsWrap, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView tag = tv("新闻纵横", 12, 0x000000, Color.WHITE);
        tag.setPadding(dp(8), dp(2), dp(8), dp(2));
        tag.setBackground(round(6, 0xFFD9362F));
        newsWrap.addView(tag);
        newsTv = tv("", 13, 0x000000, 0xFFD7E3F7);
        newsTv.setSingleLine(true);
        newsTv.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        newsTv.setMarqueeRepeatLimit(-1);
        newsTv.setFocusable(true);
        newsTv.setFocusableInTouchMode(true);
        newsWrap.addView(newsTv);
        bottomBar.addView(btn("⌨️", () -> showTextInput()));
        bottomBar.addView(vspace(6));
        bottomBar.addView(btn("⚙️", () -> showSettings()));

        root.addView(base, new LinearLayout.LayoutParams(-1, -1));
        refreshStagePersona();
        buildChips();
        hideUi();
    }

    // ================================================================ welcome/stage views
    private LinearLayout buildWelcome() {
        LinearLayout w = col(); w.setGravity(Gravity.CENTER);
        TextView h1 = tv("欢迎入住，请选择您的陪伴管家", 26, 0x000000, Color.WHITE);
        w.addView(h1);
        TextView sub = tv("直接对电视说：「我想让小姐姐陪我」或「我想让小哥哥陪我」", 13, 0x000000, 0xFF9FB3D1);
        sub.setPadding(0, dp(8), 0, dp(26));
        w.addView(sub);
        LinearLayout cards = row(); cards.setGravity(Gravity.CENTER);
        w.addView(cards);
        cards.addView(personaCard("xiaonuan"));
        cards.addView(vspace(26));
        cards.addView(personaCard("azhe"));
        listenRow = tv("正在聆听…", 14, 0x000000, 0xFF9FB3D1);
        listenRow.setGravity(Gravity.CENTER);
        listenRow.setPadding(0, dp(20), 0, 0);
        w.addView(listenRow);
        return w;
    }
    private LinearLayout personaCard(final String pid) {
        LinearLayout card = col();
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(12), dp(14), dp(12), dp(12));
        card.setBackground(round(18, 0xE81A2E4E));
        android.graphics.drawable.GradientDrawable border = round(18, 0x241A2E4E);
        border.setStroke(dp(1), 0x22FFFFFF);
        card.setBackground(border);
        card.setOnClickListener(v -> handleText(pid.equals("azhe") ? "我想让小哥哥陪我" : "我想让小姐姐陪我"));
        CircleIv img = new CircleIv(this);
        img.setImageResource(pid.equals("azhe") ? R_drawable_azhe : R_drawable_xiaonuan);
        img.setLayoutParams(new LinearLayout.LayoutParams(dp(140), dp(150)));
        card.addView(img);
        String nm = "", tg = "";
        for (String[] p : C.PERSONAS) if (p[0].equals(pid)) { nm = p[1]; tg = p[2]; }
        TextView nmT = tv(nm, 22, 0x000000, Color.WHITE);
        nmT.setGravity(Gravity.CENTER);
        nmT.setPadding(0, dp(6), 0, 0);
        card.addView(nmT);
        TextView tgT = tv(tg, 12, 0x000000, 0xFF9FB3D1);
        tgT.setGravity(Gravity.CENTER);
        card.addView(tgT);
        return card;
    }

    private LinearLayout buildStage() {
        LinearLayout s = col(); s.setGravity(Gravity.CENTER_HORIZONTAL);
        stageWrap = new FrameLayout(this);
        stageWrap.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(220)));
        avatar = new CircleIv(this);
        avatar.setLayoutParams(new FrameLayout.LayoutParams(dp(200), dp(200), Gravity.CENTER));
        stageWrap.addView(avatar);
        s.addView(stageWrap, new LinearLayout.LayoutParams(-1, dp(230), 0));

        nameTag = tv("小暖 · 温柔管家 · 小姐姐", 15, 0x000000, 0xFFFFD27A);
        nameTag.setGravity(Gravity.CENTER);
        nameTag.setBackground(round(30, 0xE60E1424));
        nameTag.setPadding(dp(18), dp(7), dp(18), dp(7));
        LinearLayout.LayoutParams ntl = lpWrap(); ntl.topMargin = dp(6);
        s.addView(nameTag, ntl);

        userLine = tv("", 13, 0x000000, 0xFF8FB0DD);
        userLine.setGravity(Gravity.CENTER);
        userLine.setPadding(0, dp(12), 0, dp(4));
        s.addView(userLine);
        aiLine = tv("你好，我是小暖～", 19, 0x000000, Color.WHITE);
        aiLine.setGravity(Gravity.CENTER);
        s.addView(aiLine);
        listenRow = tv("正在聆听…", 12, 0x000000, 0xFF5C7299);
        listenRow.setGravity(Gravity.CENTER);
        listenRow.setPadding(0, dp(8), 0, 0);
        s.addView(listenRow);
        View sp = new View(this); sp.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        s.addView(sp);
        return s;
    }

    private void buildChips() {
        chipsRow.removeAllViews();
        String[] chips = phase == 0 ? C.WELCOME_CHIPS : C.STAGE_CHIPS;
        for (String c : chips) {
            TextView chip = tv(c, 13, 0x000000, 0xFFCFE0F8);
            chip.setPadding(dp(13), dp(7), dp(13), dp(7));
            android.graphics.drawable.GradientDrawable g = round(30, 0x120A1226);
            g.setStroke(dp(1), 0x2EFFFFFF);
            chip.setBackground(g);
            chip.setOnClickListener(v -> handleText(c));
            chipsRow.addView(chip);
            chipsRow.addView(vspace(8));
        }
        if (phase == 1) {
            String[] acts = {"🎛️ 设备", "🏨 知识库", "🔒 隐私", "📱 助手"};
            for (String a : acts) {
                TextView chip = tv(a, 13, 0x000000, 0xFFFFD9C9);
                chip.setPadding(dp(13), dp(7), dp(13), dp(7));
                android.graphics.drawable.GradientDrawable g = round(30, 0x1AA51B2B);
                g.setStroke(dp(1), 0x66E8403F);
                chip.setBackground(g);
                final String which = a;
                chip.setOnClickListener(v -> {
                    if (which.contains("设备")) showDevicesPanel();
                    else if (which.contains("知识")) showKbPanel(null);
                    else if (which.contains("隐私")) showPrivacyPanel();
                    else showPhoneAssistPanel();
                });
                chipsRow.addView(chip);
                chipsRow.addView(vspace(8));
            }
        }
    }

    // ================================================================ 面板
    private void panel(String title, View body, boolean scrollable) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(title);
        if (scrollable) { ScrollView sv = new ScrollView(this); sv.addView(body); b.setView(sv); }
        else b.setView(body);
        b.setNegativeButton("关闭", null);
        AlertDialog d = b.create();
        d.getWindow().setBackgroundDrawable(round(18, 0xFF0D203F));
        try { d.show(); } catch (Exception ignored) {}
    }

    private void showTextInput() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("⌨️ 文字输入（遥控器/语音异常备用）");
        EditText et = new EditText(this);
        et.setHint("例如：把空调调到22度 / 杭州天气 / 我要退房");
        et.setTextSize(16);
        b.setView(et);
        b.setPositiveButton("发送", (d, w) -> handleText(et.getText().toString()));
        b.setNegativeButton("取消", null);
        b.show();
    }

    private void showSettings() {
        LinearLayout box = col(); box.setPadding(dp(24), dp(6), dp(24), dp(4));
        box.addView(tv("API 地址 (OpenAI 兼容)", 13, 0x000000, 0xFF9FB3D1));
        EditText eBase = new EditText(this); eBase.setText(base); box.addView(eBase);
        box.addView(tv("模型名", 13, 0x000000, 0xFF9FB3D1));
        EditText eModel = new EditText(this); eModel.setText(model); box.addView(eModel);
        box.addView(tv("API Key（由你在本机填写）", 13, 0x000000, 0xFF9FB3D1));
        EditText eKey = new EditText(this); eKey.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD); eKey.setText(apiKey); box.addView(eKey);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("⚙️ 模型设置");
        b.setView(box);
        b.setPositiveButton("保存", (d, w) -> { base = eBase.getText().toString().trim(); model = eModel.getText().toString().trim();
            String enteredKey = eKey.getText().toString().trim(); if (!LocalSecrets.save(prefs, enteredKey)) { toast("密钥无法加密保存，请稍后重试"); return; } apiKey = enteredKey; prefs.edit().putString("base", base).putString("model", model).apply();
            toast("已保存"); });
        b.setNegativeButton("取消", null);
        b.show();
    }

    private void showDevicesPanel() {
        LinearLayout box = col();
        box.setPadding(dp(18), dp(4), dp(18), dp(4));
        String[] names = {"light", "ac", "curtain", "tv"};
        String[] labels = {"💡 灯光", "❄️ 空调", "🪟 窗帘", "📺 电视"};
        final java.util.LinkedHashMap<String, Map<String, Object>> dev = devices;
        for (int i = 0; i < 4; i++) {
            final String key = names[i];
            final String lbl = labels[i];
            Map<String, Object> st = dev.get(key);
            TextView t = tv(lbl, 17, 0x000000, Color.WHITE);
            box.addView(t);
            TextView stv = tv(statusLine(key, st), 13, 0x000000, 0xFF9FB3D1);
            box.addView(stv);
            Button toggle = new Button(this);
            toggle.setText("开 / 关");
            toggle.setOnClickListener(v -> {
                boolean on = !Boolean.TRUE.equals(dev.get(key).get("on"));
                Map<String, Object> m = dev.get(key);
                m.put("on", on);
                if (key.equals("curtain")) m.put("open", on ? 100 : 0);
                toast((on ? "已开启 " : "已关闭 ") + lbl.replaceFirst("^\\S+ ", ""));
            });
            box.addView(toggle);
        }
        panel("🎛️ 房间设备控制", box, false);
    }
    private String statusLine(String key, Map<String, Object> st) {
        switch (key) {
            case "light": return Boolean.TRUE.equals(st.get("on")) ? "已开启 · " + st.get("brightness") + "%" : "已关闭";
            case "ac": return Boolean.TRUE.equals(st.get("on")) ? "制冷 " + st.get("temp") + "℃" : "已关闭";
            case "curtain": return ((Integer) st.get("open")) > 5 ? "开启 " + st.get("open") + "%" : "已关闭";
            default: return Boolean.TRUE.equals(st.get("on")) ? String.valueOf(st.get("channel")) : "已关闭";
        }
    }
    private void refreshDevPanelTexts() {}

    private void showKbPanel(List<String[]> sources) {
        LinearLayout box = col(); box.setPadding(dp(18), dp(4), dp(18), dp(4));
        if (sources != null && !sources.isEmpty()) {
            TextView h = tv("📌 本次回答依据", 15, 0x000000, 0xFFFFD27A);
            box.addView(h);
            for (String[] s : sources) { box.addView(tv(s[0] + "：" + s[1], 13, 0x000000, 0xFFCFE0F8)); }
            box.addView(vspace(6));
        }
        TextView h2 = tv("🏨 酒店知识库（" + kb.size() + " 条）", 15, 0x000000, Color.WHITE);
        box.addView(h2);
        for (String[] e : kb) box.addView(tv("· " + e[0] + "：" + (e[1].length() > 40 ? e[1].substring(0, 40) + "…" : e[1]), 12, 0x000000, 0xFF9FB3D1));
        TextView hint = tv("💡 说「搜索」或直接问酒店问题，AI 会回答；导入功能在电脑版演示中可用。", 11, 0x000000, 0xFF5C7299);
        hint.setPadding(0, dp(10), 0, 0);
        box.addView(hint);
        panel("🏨 酒店知识库", box, true);
    }

    private void showPhoneAssistPanel() {
        LinearLayout box = col(); box.setPadding(dp(18), dp(4), dp(18), dp(4));
        boolean on = PhoneAssistService.running;
        box.addView(tv((on ? "🟢 手机助手已开启" : "🔴 手机助手未开启（需手动授权一次）"), 16, 0x000000, on ? 0xFF37D67A : 0xFFE8403F));
        TextView cmds = tv("支持语音指令：\n· 返回 / 回桌面 / 最近任务 / 下拉通知栏\n· 打开微信 / 打开抖音 / 打开相机…\n· 音量调大 / 音量调小 / 静音\n· 亮度调高 / 亮度调暗 / 亮度最高", 14, 0x000000, 0xFFCFE0F8);
        cmds.setPadding(0, dp(8), 0, dp(6));
        box.addView(cmds);
        box.addView(tv("安全说明：无障碍服务仅在你下指令时执行对应动作，不监听、不上传任何内容；可随时在系统设置中关闭。", 11, 0x000000, 0xFF5C7299));
        box.addView(vspace(8));
        Button b1 = new Button(this);
        b1.setText(on ? "打开无障碍设置（检查/关闭）" : "去开启无障碍服务");
        b1.setOnClickListener(v -> PhoneCmd.openAccessibilitySettings(this));
        box.addView(b1);
        box.addView(vspace(6));
        Button b2 = new Button(this);
        b2.setText("授权「修改系统设置」（调节亮度需要）");
        b2.setOnClickListener(v -> PhoneCmd.openWriteSettings(this));
        box.addView(b2);
        panel("📱 手机助手（无障碍操控）", box, false);
    }

    private void showPrivacyPanel() {
        LinearLayout box = col(); box.setPadding(dp(18), dp(4), dp(18), dp(4));
        box.addView(tv("🎙️ 麦克风：" + (micOn ? "开启（指示灯亮）" : "关闭"), 16, 0x000000, Color.WHITE));
        Button m = new Button(this); m.setText(micOn ? "关闭麦克风" : "开启麦克风");
        m.setOnClickListener(v -> { setMic(!micOn, ""); });
        box.addView(m);
        box.addView(vspace(6));
        box.addView(tv("会话记录：" + hist.length() + " 条（仅存本机）", 14, 0x000000, 0xFF9FB3D1));
        box.addView(vspace(8));
        Button co = new Button(this); co.setText("🧳 我要退房 · 一键清除全部数据");
        co.setOnClickListener(v -> handleText("我要退房"));
        box.addView(co);
        box.addView(vspace(8));
        box.addView(tv("演示环境为本地模拟设备；真实部署时设备控制由红外/物联网网关执行，退房即清为硬性隐私合规设计。", 11, 0x000000, 0xFF5C7299));
        panel("🔒 隐私合规中心", box, false);
    }

    private void showStory(String text, boolean sleepScene) {
        storyOverlayShown = true;
        if (sleepScene) overlayDim = new View(this); // 用弹窗代替暗化
        LinearLayout box = col(); box.setPadding(dp(18), dp(4), dp(18), dp(4));
        TextView t = tv(text, 16, 0x000000, 0xFFEEF4FF);
        t.setLineSpacing(dp(5), 1f);
        box.addView(t);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(sleepScene ? "🌙 晚安故事 · 已开启睡前氛围" : "🌙 晚安故事");
        ScrollView sv = new ScrollView(this); sv.addView(box);
        b.setView(sv);
        b.setPositiveButton("🔊 重新播放", (d, w) -> speak(text, personaVoice()));
        b.setNegativeButton("关闭", (d, w) -> { storyOverlayShown = false; });
        b.show();
    }
    private void closeStoryOverlay() { storyOverlayShown = false; }

    // ================================================================ 新闻/其它
    private void runNews() {
        StringBuilder sb = new StringBuilder();
        for (String n : C.NEWS) sb.append(n).append("    ");
        newsTv.setText(sb.toString());
        newsTv.requestFocus();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void hideUi() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        } catch (Throwable ignored) {}
    }

    // ================================================================ 小工具
    private int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    private TextView tv(String s, float sp, int style, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout col() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout.LayoutParams lpWrap() { return new LinearLayout.LayoutParams(-2, -2); }
    private View vspace(int dp) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp, 1)); return v; }
    private android.graphics.drawable.GradientDrawable round(int r, int color) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setCornerRadius(dp(r)); d.setColor(color); return d;
    }
    private TextView btn(String s, Runnable on) {
        TextView t = tv(s, 14, 0x000000, 0xFFCFE0F8);
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        android.graphics.drawable.GradientDrawable g = round(10, 0xCC10192E);
        g.setStroke(dp(1), 0x33FFFFFF);
        t.setBackground(g);
        t.setOnClickListener(v -> on.run());
        return t;
    }

    // ================================================================ 圆形头像（加固版）
    static class CircleIv extends ImageView {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        public CircleIv(Context c) {
            super(c);
            ringPaint.setStyle(Paint.Style.STROKE);
            try { ringPaint.setStrokeWidth(dp(3)); } catch (Throwable ignored) {}
            ringPaint.setColor(0xAAFFFFFF);
        }
        @Override protected void onDraw(Canvas canvas) {
            try {
                android.graphics.drawable.Drawable dr = getDrawable();
                if (dr == null) { super.onDraw(canvas); return; }
                Bitmap bm;
                if (dr instanceof android.graphics.drawable.BitmapDrawable) {
                    bm = ((android.graphics.drawable.BitmapDrawable) dr).getBitmap();
                } else {
                    super.onDraw(canvas); return;
                }
                int w = getWidth(), h = getHeight();
                if (w <= 0 || h <= 0 || bm == null) { super.onDraw(canvas); return; }
                float r = Math.min(w, h) / 2f - dp(1);
                if (r <= 0) return;
                canvas.drawCircle(w / 2f, h / 2f, r + dp(2), ringPaint);
                BitmapShader sh = new BitmapShader(bm, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                float scale = Math.max(w / (float) bm.getWidth(), h / (float) bm.getHeight());
                android.graphics.Matrix m = new android.graphics.Matrix();
                float dx = (w - bm.getWidth() * scale) / 2f, dy = (h - bm.getHeight() * scale) / 2f;
                m.setScale(scale, scale); m.postTranslate(dx, dy);
                sh.setLocalMatrix(m);
                paint.setShader(sh);
                canvas.drawCircle(w / 2f, h / 2f, r, paint);
            } catch (Throwable t) {
                try { super.onDraw(canvas); } catch (Throwable ignored) {}
            }
        }
        private static int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, android.content.res.Resources.getSystem().getDisplayMetrics()); }
    }

    // ================================================================ 天空背景
    static class SkyView extends View {
        private final Paint gp = new Paint(), sp = new Paint(), bp = new Paint();
        private final Random rnd = new Random(7);
        private final float[] sx, sy, ss, so;
        private final int[] bws, bhs, bxs;
        public SkyView(Context c) {
            super(c);
            sx = new float[110]; sy = new float[110]; ss = new float[110]; so = new float[110];
            for (int i = 0; i < 110; i++) { sx[i] = rnd.nextFloat(); sy[i] = rnd.nextFloat() * 0.6f; ss[i] = 1 + rnd.nextFloat() * 2.4f; so[i] = 0.3f + rnd.nextFloat() * 0.6f; }
            int n = 22; bws = new int[n]; bhs = new int[n]; bxs = new int[n];
            int x = 0;
            for (int i = 0; i < n; i++) { int w = 20 + rnd.nextInt(60); bws[i] = w; bxs[i] = x; bhs[i] = 40 + rnd.nextInt(160); x += w + 8; }
        }
        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            gp.setShader(new LinearGradient(0, 0, 0, h, 0xFF10294F, 0xFF050D1E, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, gp);
            for (int i = 0; i < sx.length; i++) {
                sp.setColor(Color.WHITE); sp.setAlpha((int) (so[i] * 255));
                c.drawCircle(sx[i] * w, sy[i] * h, ss[i], sp);
            }
            bp.setColor(0xFF040B1C);
            int groundY = (int) (h * 0.78f);
            for (int i = 0; i < bws.length; i++) {
                int bh = Math.min(bhs[i], h - groundY - 10);
                c.drawRect(bxs[i] * w / 1000f, groundY - bh, (bxs[i] + bws[i]) * w / 1000f, groundY, bp);
            }
            Paint wp = new Paint(); wp.setColor(0xFFFFD98A); wp.setAlpha(110);
            for (int i = 0; i < 40; i++) {
                float wx = rnd.nextFloat() * w; float wy = groundY - rnd.nextInt((int) (h * 0.20f));
                c.drawRect(wx, wy, wx + 2.5f, wy + 3.5f, wp);
            }
            wp.setColor(0x88FFD98A);
            c.drawCircle(w * 0.86f, h * 0.18f, 34, wp);
        }
    }
}
