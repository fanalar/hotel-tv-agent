from pathlib import Path
import urllib.request,zipfile,shutil,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
URL="https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip"
def main():
    cache=ROOT/".cache"/"vosk";cache.mkdir(parents=True,exist_ok=True)
    archive=cache/"model.zip"
    if not archive.exists():
        with urllib.request.urlopen(URL,timeout=90) as source,archive.open("wb") as target:shutil.copyfileobj(source,target)
    destination=ROOT/"android/app/src/main/assets/vosk-model-cn";destination.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        z.testzip()
        for item in z.infolist():
            if item.is_dir():continue
            parts=Path(item.filename).parts
            if not parts or parts[0]!="vosk-model-small-cn-0.22" or ".." in parts:raise RuntimeError("Unexpected model archive")
            target=destination/Path(*parts[1:]);target.parent.mkdir(parents=True,exist_ok=True)
            with z.open(item) as source,target.open("wb") as out:shutil.copyfileobj(source,out)
    print("Public Vosk model prepared; upstream model license is Apache-2.0")
if __name__=="__main__":main()
