"""AI 接入层：OpenAI 兼容协议 -> DeepSeek（对话/意图/故事/问答统一走此）
无 Key 或网络失败时自动降级为本地规则回复，保证演示不中断。
"""
import asyncio
import json
import re

import httpx

import config


class AIService:
    def __init__(self):
        self.key = config.DEEPSEEK_API_KEY
        self.base = config.DEEPSEEK_BASE_URL
        self.model = config.DEEPSEEK_MODEL
        self._fallback_models = ["deepseek-chat", "deepseek-reasoner", "deepseek-v3"]
        self.timeout = httpx.Timeout(40.0, connect=8.0)

    @property
    def available(self) -> bool:
        return bool(self.key)

    async def chat(self, messages: list[dict], temperature: float = 0.7, max_tokens: int = 600) -> str | None:
        """返回文本；失败返回 None（调用方降级）。自动尝试候选模型名。"""
        if not self.available:
            return None
        models = [self.model, *self._fallback_models]
        last_err = None
        for m in models:
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as cli:
                    r = await cli.post(
                        f"{self.base}/chat/completions",
                        headers={"Authorization": f"Bearer {self.key}"},
                        json={
                            "model": m,
                            "messages": messages,
                            "temperature": temperature,
                            "max_tokens": max_tokens,
                        },
                    )
                if r.status_code == 200:
                    data = r.json()
                    return data["choices"][0]["message"]["content"].strip()
                last_err = f"{m}: HTTP {r.status_code} "
                if r.status_code == 401:
                    return None  # key 无效，任何模型都没用
            except Exception as e:  # noqa: BLE001
                last_err = f"{m}: {type(e).__name__}"
                await asyncio.sleep(0.4)
        print(f"[aihub] LLM 调用失败: {last_err}")
        return None


ai = AIService()

_PUNCT = re.compile(r"[\s，。！？、；：""''（）【】《》,.!?;:()\[\]·\-—~～]")


def _strip(text: str) -> str:
    return _PUNCT.sub("", text)


def _has(text: str, *words: str) -> bool:
    t = _strip(text)
    return any(w in t for w in words)


def _startswith(text: str, *words: str) -> bool:
    t = _strip(text)
    return any(t.startswith(w) for w in words)


# ---------- 设备指令解析（parse_device_command 为准） ----------



def parse_device_command(text: str) -> str | None:
    """返回设备指令 key；无匹配返回 None"""
    t = _strip(text)
    rules = [
        ("light_on", ["开灯", "打开灯", "开下灯", "亮灯"]),
        ("light_off", ["关灯", "关闭灯", "把灯关"]),
        ("ac_on", ["空调开", "开空调", "空调制冷", "空调冷"]),
        ("ac_off", ["关空调", "空调关"]),
        ("curtain_open", ["开窗帘", "打开窗帘", "拉开窗帘", "窗帘开"]),
        ("curtain_close", ["关窗帘", "拉上窗帘", "关上窗帘", "窗帘关"]),
        ("tv_off", ["关电视", "电视关"]),
        ("tv_on", ["开电视", "打开电视", "电视开"]),
        ("sleep", ["睡眠模式", "睡前模式", "晚安模式", "睡觉模式"]),
        ("volume_up", ["音量调大", "声音大点", "大声"]),
        ("volume_down", ["音量调小", "声音小点", "小声"]),
        ("channel_news", ["新闻联播", "新闻频道", "看新闻", "听新闻"]),
    ]
    for key, words in rules:
        if _has(t, *words):
            return key
    # 数字规则
    m = re.search(r"空调.{0,6}(\d{1,2})", t)
    if m:
        return "ac_temp"
    m = re.search(r"(灯|亮度).{0,6}(\d{1,3})", t)
    if m:
        return "light_dim"
    m = re.search(r"窗帘.{0,6}(\d{1,3})", t)
    if m:
        return "curtain_pct"
    if _has(t, "新闻联播"):
        return "channel_news"
    return None


def classify(text: str) -> str:
    """意图分类：checkout / dialect / switch / story / device / weather / kb / search / chat"""
    t = _strip(text)
    if _has(t, "我要退房", "退房", "清除数据", "清空聊天", "清空数据", "删除记录", "保护隐私", "麦克风"):
        return "checkout"
    if _has(t, "粤语", "广东话"):
        return "dialect_yue"
    if _has(t, "四川话"):
        return "dialect_sichuan"
    if _has(t, "晚安", "讲故事", "故事", "哄睡", "睡觉了", "睡吧", "睡前"):
        return "story"
    if parse_device_command(text) is not None:
        return "device"
    if _has(t, "天气", "气温", "下雨", "台风", "多少度", "几度", "冷不冷", "热不热", "会不会下", "几号"):
        return "weather"
    if _has(t, "附近", "推荐", "好吃", "好玩", "怎么去", "几点", "有没有", "早餐", "退房时间",
             "健身房", "游泳", "泳池", "酒廊", "送餐", "点餐", "洗衣", "wifi", "无线", "密码",
             "机场", "打车", "停车", "西湖", "景点", "餐厅", "美食", "饭店", "酒店", "哪里", "如何",
             "介绍", "开放"):
        return "kb"
    if _has(t, "搜索", "搜一下", "查一下", "查一查", "查查", "最新", "热点", "实时", "新闻",
             "发生了什么", "网上", "百度一下"):
        return "search"
    if _has(t, "我想让小姐姐", "我想让小哥哥", "换小姐姐", "换小哥哥", "换小暖", "换阿哲",
             "换个美女", "换个帅哥", "让小姐姐陪我", "让小哥哥陪我"):
        return "switch"
    return "chat"


SWITCH_RULES = [
    ("xiaonuan", ["小暖", "小姐姐", "美女", "姐姐", "温柔"]),
    ("azhe", ["阿哲", "小哥哥", "帅哥", "哥哥", "儒雅"]),
]


def detect_switch_persona(text: str) -> str | None:
    t = _strip(text)
    for pid, words in SWITCH_RULES:
        if any(w in t for w in words):
            return pid
    return None


def fallback_reply(persona: dict, text: str) -> str:
    """无 LLM 时的本地兜底回复"""
    n = persona["name"]
    if "你好" in text or "在吗" in text:
        return f"你好呀，我是{n}，很高兴陪着你。想聊聊天、听故事，还是了解酒店服务？直接跟我说就行～"
    if "谢谢" in text:
        return "不客气～能帮到你我很开心。"
    if "累" in text or "烦" in text or "难过" in text or "压力" in text:
        return f"辛苦了，先深呼吸一下。你现在安全地在房间里，我就在这里陪着你。要不要我给你讲个轻松的小故事，或者把灯光调成暖暖的？"
    if "名字" in text:
        return f"我叫{n}，是示例酒店的AI管家，负责陪你聊聊天、管理房间设备、解答酒店问题～"
    return f"我在呢，我是{n}。你可以跟我说「开灯」「空调调到26度」「附近有什么好吃的」「讲个晚安故事」「我要退房」等，我都能听懂哦。"


# ================================================================
# 实时联网工具（天气 / 网页搜索）—— 直连失败自动走本机代理 127.0.0.1:10808
# ================================================================
_PROXY = "http://127.0.0.1:10808"
_CITY_PINYIN = {
    "北京": "beijing", "上海": "shanghai", "广州": "guangzhou", "深圳": "shenzhen",
    "杭州": "hangzhou", "成都": "chengdu", "重庆": "chongqing", "武汉": "wuhan",
    "西安": "xian", "南京": "nanjing", "天津": "tianjin", "苏州": "suzhou",
    "长沙": "changsha", "青岛": "qingdao", "厦门": "xiamen", "昆明": "kunming",
    "三亚": "sanya", "哈尔滨": "haerbin", "乌鲁木齐": "wulumuqi", "拉萨": "lasa",
}
_WMO = {
    0: "晴", 1: "大致晴朗", 2: "多云", 3: "阴", 45: "雾", 48: "雾凇", 51: "小毛毛雨",
    53: "毛毛雨", 55: "大毛毛雨", 56: "冻毛毛雨", 57: "强冻毛毛雨", 61: "小雨", 63: "中雨",
    65: "大雨", 66: "冻雨", 67: "强冻雨", 71: "小雪", 73: "中雪", 75: "大雪", 77: "雪粒",
    80: "小阵雨", 81: "阵雨", 82: "强阵雨", 85: "小阵雪", 86: "阵雪", 95: "雷暴",
    96: "雷暴伴小冰雹", 99: "雷暴伴大冰雹",
}


def _http_get(url: str, timeout: float = 12.0) -> str | None:
    """直连优先，失败走本机代理"""
    import httpx
    for proxy in (None, _PROXY):
        try:
            with httpx.Client(proxy=proxy, timeout=timeout, follow_redirects=True,
                              headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}) as cli:
                r = cli.get(url)
            if r.status_code == 200:
                return r.text
        except Exception:  # noqa: BLE001
            continue
    return None


def extract_city(text: str) -> str | None:
    """从问句中提取城市名；缺省用酒店所在城市杭州"""
    for city in _CITY_PINYIN:
        if city in text:
            return city
    return None  # caller 决定默认


def fetch_weather(city: str, text: str = "") -> str | None:
    """Open-Meteo 实时天气（无 key）。返回中文播报；失败 None"""
    import json
    geocoded = None
    q = city
    if city not in _CITY_PINYIN:
        # 尝试地理编码
        raw = _http_get(f"https://geocoding-api.open-meteo.com/v1/search?name={q}&count=1&language=zh&format=json")
        if raw:
            try:
                d = json.loads(raw)
                if d.get("results"):
                    r = d["results"][0]
                    geocoded = (r["latitude"], r["longitude"], r.get("name", city))
            except Exception:  # noqa: BLE001
                pass
    if not geocoded:
        pinyin = _CITY_PINYIN.get(city)
        if not pinyin:
            return None
        raw = _http_get(f"https://geocoding-api.open-meteo.com/v1/search?name={pinyin}&count=1&language=zh&format=json")
        if raw:
            try:
                d = json.loads(raw)
                if d.get("results"):
                    r = d["results"][0]
                    geocoded = (r["latitude"], r["longitude"], r.get("name", city))
            except Exception:  # noqa: BLE001
                pass
    if not geocoded:
        # 兜底：按拼音城市表给坐标
        fallback_coord = {
            "beijing": (39.90, 116.40), "shanghai": (31.23, 121.47), "guangzhou": (23.13, 113.26),
            "shenzhen": (22.54, 114.06), "hangzhou": (30.27, 120.16), "chengdu": (30.57, 104.07),
            "chongqing": (29.56, 106.55), "wuhan": (30.59, 114.31), "xian": (34.34, 108.94),
            "nanjing": (32.06, 118.80), "tianjin": (39.13, 117.20), "suzhou": (31.30, 120.58),
            "changsha": (28.23, 112.94), "qingdao": (36.07, 120.38), "xiamen": (24.48, 118.09),
            "kunming": (25.04, 102.71), "sanya": (18.25, 109.51), "haerbin": (45.80, 126.53),
            "wulumuqi": (43.83, 87.62), "lasa": (29.65, 91.14),
        }
        coord = fallback_coord.get(_CITY_PINYIN.get(city, ""))
        if not coord:
            return None
        geocoded = (coord[0], coord[1], city)
    lat, lon, name = geocoded
    raw = _http_get(
        f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
        f"&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
        f"&timezone=Asia%2FShanghai&forecast_days=3"
    )
    if not raw:
        return None
    try:
        d = json.loads(raw)
        daily = d["daily"]
        # 按问句中的 后天/明天 定位起始日期（缺省今天）
        start = 2 if ("后天" in text or "大后天" in text) else (1 if "明天" in text or "明儿" in text else 0)
        labels = ["今天", "明天", "后天"]
        parts = []
        for i in range(start, min(3, len(daily["time"]))):
            code = daily["weather_code"][i]
            desc = _WMO.get(code, f"天气代码{code}")
            tmax, tmin = daily["temperature_2m_max"][i], daily["temperature_2m_min"][i]
            pop = daily["precipitation_probability_max"][i]
            pop_txt = f"，降水概率{pop}%" if pop is not None and pop > 10 else ""
            parts.append(f"{labels[i]}{name}{desc}，{tmin:.0f}~{tmax:.0f}℃{pop_txt}")
        return "、".join(parts) + "。需要我帮您安排出行吗？"
    except Exception:  # noqa: BLE001
        return None


def web_search(query: str, top: int = 3) -> str | None:
    """必应实时搜索（直连/代理），返回拼接文本；失败 None"""
    import html as _html
    import re as _re
    url = f"https://cn.bing.com/search?q={_re.escape(query)}&setlang=zh-hans"
    raw = _http_get(url, timeout=14.0)
    if not raw:
        return None
    items = []
    for m in _re.finditer(r'<li class="b_algo".*?</li>', raw, _re.S):
        block = m.group(0)
        hm = _re.search(r'<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', block, _re.S)
        if not hm:
            continue
        link = hm.group(1)
        title = _re.sub(r"<[^>]+>", "", hm.group(2))
        sm = _re.search(r"<p[^>]*>(.*?)</p>", block, _re.S)
        snip = _re.sub(r"<[^>]+>", "", sm.group(1)) if sm else ""
        items.append(f"{_html.unescape(title.strip())} —— {_html.unescape(snip.strip())[:90]}")
        if len(items) >= top:
            break
    if not items:
        return None
    return "我帮您在网络上查到：\n" + "\n".join(f"{i + 1}. {it}" for i, it in enumerate(items))
