"""SQLite 数据库（会话消息/设备状态），零外部依赖"""
import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

from config import DB_PATH, HOTEL_NAME

_lock = threading.Lock()

DEFAULT_DEVICES = {
    "light": {"on": False, "brightness": 80, "label": "灯光"},
    "ac": {"on": False, "temp": 26, "mode": "制冷", "label": "空调"},
    "curtain": {"open": 100, "label": "窗帘"},
    "tv": {"on": True, "volume": 30, "channel": "演示频道·高清 008", "label": "电视"},
}


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with get_conn() as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS device_states(
                key TEXT PRIMARY KEY, value TEXT NOT NULL)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS kb_entries(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                source TEXT DEFAULT '预设')"""
        )
    # 设备默认状态
    with get_conn() as c:
        for k, v in DEFAULT_DEVICES.items():
            c.execute("INSERT OR IGNORE INTO device_states(key, value) VALUES(?,?)", (k, json.dumps(v, ensure_ascii=False)))
    _seed_kb()


def _seed_kb():
    entries = [
        ("示例", "早餐说明", "此为演示知识库。早餐时间与地点请向前台确认。", "开源演示"),
        ("示例", "退房说明", "此为演示知识库。实际退房时间请向前台确认。", "开源演示"),
        ("示例", "网络说明", "此为演示知识库，不包含真实WiFi账号或密码。请向前台索取网络信息。", "开源演示"),
    ]
    with get_conn() as c:
        if c.execute("SELECT COUNT(*) FROM kb_entries").fetchone()[0] == 0:
            c.executemany("INSERT INTO kb_entries(category,title,content,source) VALUES(?,?,?,?)", entries)


def add_message(session: str, role: str, content: str):
    with _lock, get_conn() as c:
        c.execute(
            "INSERT INTO messages(session, role, content, created_at) VALUES(?,?,?,?)",
            (session, role, content, datetime.now().isoformat(timespec="seconds")),
        )


def get_history(session: str, limit: int = 20):
    with get_conn() as c:
        rows = c.execute(
            "SELECT role, content FROM messages WHERE session=? ORDER BY id DESC LIMIT ?",
            (session, limit),
        ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def get_devices():
    with get_conn() as c:
        rows = c.execute("SELECT key, value FROM device_states").fetchall()
    return {r["key"]: json.loads(r["value"]) for r in rows}


def update_device(key: str, patch: dict):
    with _lock, get_conn() as c:
        row = c.execute("SELECT value FROM device_states WHERE key=?", (key,)).fetchone()
        val = json.loads(row["value"]) if row else {}
        val.update(patch)
        c.execute(
            "INSERT INTO device_states(key, value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(val, ensure_ascii=False)),
        )
    return val


def reset_devices():
    with _lock, get_conn() as c:
        for k, v in DEFAULT_DEVICES.items():
            c.execute(
                "INSERT INTO device_states(key, value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (k, json.dumps(v, ensure_ascii=False)),
            )


def checkout(session: str):
    """退房即清：删除该会话全部消息 + 设备恢复默认"""
    with _lock, get_conn() as c:
        c.execute("DELETE FROM messages WHERE session=?", (session,))
    reset_devices()


def all_kb():
    with get_conn() as c:
        rows = c.execute("SELECT id, category, title, content, source FROM kb_entries").fetchall()
    return [dict(r) for r in rows]


def add_kb(category: str, title: str, content: str):
    with _lock, get_conn() as c:
        cur = c.execute(
            "INSERT INTO kb_entries(category, title, content, source) VALUES(?,?,?, '手动导入')",
            (category, title, content),
        )
        return cur.lastrowid


def delete_kb(kid: int):
    with _lock, get_conn() as c:
        c.execute("DELETE FROM kb_entries WHERE id=?", (kid,))
