"""酒店电视 AI 智能体情绪价值 - 本地部署版后端服务
FastAPI + SQLite；AI 能力经 DeepSeek(OpenAI 兼容)；TTS 走 edge-tts。
"""
import io
import json
import os
import random
import re
import uuid

import edge_tts
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import config
import database as db
import knowledge
from aihub import (ai, classify, detect_switch_persona, extract_city, fallback_reply,
                   fetch_weather, parse_device_command, web_search)

app = FastAPI(title="酒店电视AI智能体·本地部署版", docs_url="/api/docs", openapi_url="/api/openapi.json")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[s for s in os.environ.get("HOTEL_ALLOWED_ORIGINS", "http://127.0.0.1:3000,http://localhost:3000").split(",") if s],
    allow_methods=["*"],
    allow_headers=["*"],
)

NEWS = ["开源演示频道，不是实时新闻", "示例酒店欢迎您，实际服务信息请咨询前台"]

# ---------------------------------------------------------------- 数据模型
class AgentReq(BaseModel):
    session: str = "guest"
    persona: str = "xiaonuan"
    text: str

class TtsReq(BaseModel):
    text: str
    voice_id: str = "xiaonuan"

class DeviceSetReq(BaseModel):
    key: str
    patch: dict

class KbImportReq(BaseModel):
    category: str = "自定义"
    title: str
    content: str

# ---------------------------------------------------------------- 基础
@app.on_event("startup")
def _startup():
    db.init_db()
    print("=== 酒店TV智能体 本地服务启动成功 ===")
    print(f"    AI(DeepSeek): {'已配置 ' + ai.model if ai.available else '未配置(将使用本地兜底回复)'}")
    print(f"    数据库: {db.DB_PATH}")


def _persona(pid: str) -> dict:
    return config.PERSONAS.get(pid, config.PERSONAS["xiaonuan"])


def _voice_for(pid: str, extra: str | None = None) -> str:
    p = _persona(pid)
    if extra in ("xiaonuan_yue", "azhe_sichuan"):
        return config.VOICE_MAP[extra]
    return p["voice"]

# ---------------------------------------------------------------- 设备执行
def update_dev(states: dict, **kw) -> dict:
    for k, patch in kw.items():
        db.update_device(k, patch)
    return db.get_devices()


def exec_device(cmd: str) -> tuple[str, dict]:
    """执行设备指令，返回 (回复文案, 最新设备快照)"""
    d = db.get_devices()
    text = ""
    if cmd == "light_on":
        d = update_dev(d, light={"on": True, "brightness": max(d["light"]["brightness"], 60)})
        text = "好嘞，房间灯光已打开。"
    elif cmd == "light_off":
        d = update_dev(d, light={"on": False})
        text = "好的，灯光已关闭，需要时喊我一声就行。"
    elif cmd == "light_dim":
        pass
    elif cmd == "ac_on":
        d = update_dev(d, ac={"on": True})
        text = "空调已开启，正在为您调节室温。"
    elif cmd == "ac_off":
        d = update_dev(d, ac={"on": False})
        text = "空调已关闭。"
    elif cmd == "curtain_open":
        d = update_dev(d, curtain={"open": 100})
        text = "窗帘已为您拉开，外面的夜景很美哦。"
    elif cmd == "curtain_close":
        d = update_dev(d, curtain={"open": 0})
        text = "窗帘已拉上，需要私密空间时随时喊我。"
    elif cmd == "tv_off":
        d = update_dev(d, tv={"on": False})
        text = "电视已关闭。"
    elif cmd == "tv_on":
        d = update_dev(d, tv={"on": True})
        text = "电视已打开，当前是直播频道。"
    elif cmd == "volume_up":
        d = update_dev(d, tv={"volume": min(100, d["tv"]["volume"] + 10)})
        text = f"音量已调大到 {d['tv']['volume']}。"
    elif cmd == "volume_down":
        d = update_dev(d, tv={"volume": max(0, d["tv"]["volume"] - 10)})
        text = f"音量已调小到 {d['tv']['volume']}。"
    elif cmd == "channel_news":
        d = update_dev(d, tv={"on": True, "channel": "央视·新闻联播"})
        text = "好的，已为您切换到新闻联播频道。"
    elif cmd == "sleep":
        d = update_dev(d, light={"on": True, "brightness": 20}, tv={"volume": 8}, curtain={"open": 0}, ac={"on": True, "temp": 26})
        text = "已为您开启睡前模式：灯光调暗、窗帘拉上、音量调低，空调保持26℃，安心休息吧，晚安～"
    return text, d


def ac_temp_reply(v: int) -> tuple[str, dict]:
    v = max(16, min(30, v))
    d = update_dev({}, ac={"on": True, "temp": v})
    return f"好的，空调已调到 {v}℃ 制冷模式。", d

def light_dim_reply(v: int) -> tuple[str, dict]:
    v = max(1, min(100, v))
    d = update_dev({}, light={"on": True, "brightness": v})
    return f"灯光亮度已调到 {v}%。", d

def curtain_reply(v: int) -> tuple[str, dict]:
    v = max(0, min(100, v))
    d = update_dev({}, curtain={"open": v})
    return f"窗帘已开到 {v}%。", d

# ---------------------------------------------------------------- 知识库问答
def kb_answer(text: str, persona_pid: str) -> tuple[str, list[dict]]:
    hits = knowledge.retrieve(text, top_k=2)
    pname = _persona(persona_pid)["name"]
    if not hits:
        return (
            f"这个我暂时没有查到呢。您可以问周边景点、美食、酒店设施或服务（比如早餐、退房时间、健身房、WiFi），"
            f"或者拨分机0问前台，{pname}也会努力帮您找答案的～",
            [],
        )
    ctx = "\n\n".join(f"【{e['title']}】{e['content']}" for e in hits)
    if ai.available:
        answer = await_llm([
            {"role": "system", "content": f"你是示例酒店的AI礼宾管家{pname}。请只依据下面酒店知识库回答客人问题，语气亲切口语化，"
                                          f"60字以内；若知识库信息不足，礼貌说明并建议咨询前台。\n\n知识库：\n{ctx}"},
            {"role": "user", "content": text},
        ])
        if answer:
            return answer, hits
    top = hits[0]
    return f"{top['content']}（来自酒店知识库：{top['title']}）", hits


def await_llm(messages: list[dict]) -> str | None:
    """同步桥接（FastAPI def 端点在线程池内，可安全 await）"""
    import asyncio
    return asyncio.run(ai.chat(messages))


STORY_FALLBACK = (
    "今晚讲一个《月亮上的小兔子》的故事。\n\n"
    "从前，月亮上住着一只毛茸茸的小兔子，它每晚都会用云朵做一张软软的床，然后数着星星入睡。"
    "有一晚，一阵风吹来，把它的云朵床吹散了一角。小兔子有点难过，星星们看见了，纷纷眨着眼睛说："
    "「别担心，我们用光给你缝起来。」于是星星们把银光一缕缕织进云朵里，床变得更软更亮了。"
    "小兔子躺上去，闻到了月亮桂花的香气，很快就睡着了，嘴角还带着甜甜的笑。\n\n"
    "晚安，愿你今晚也像小兔子一样，枕着星光，做个好梦。"
)


def gen_story(persona_pid: str, text: str) -> str:
    p = _persona(persona_pid)
    if ai.available:
        s = await_llm([
            {"role": "system", "content": f"你是{p['name']}，请为酒店客人创作一个温柔治愈的睡前晚安故事。"
                                          f"要求：150~230字、中文、适合睡前听、结尾有晚安祝福。直接输出故事正文。"},
            {"role": "user", "content": text},
        ])
        if s:
            return s
    return STORY_FALLBACK


# ---------------------------------------------------------------- 主智能体入口
@app.post("/api/agent")
def agent(req: AgentReq):
    session = req.session or "guest"
    persona_pid = req.persona if req.persona in config.PERSONAS else "xiaonuan"
    text = (req.text or "").strip()
    if not text:
        return JSONResponse({"detail": "empty text"}, status_code=400)

    db.add_message(session, "user", text)

    # 1) 人物切换（提到其他管家名字时优先）
    target = detect_switch_persona(text)
    want_story = re.search(r"晚安|故事|哄睡|讲故事", text)
    if target and target != persona_pid:
        np = _persona(target)
        persona_pid = target
        db.add_message(session, "assistant", f"[切换至{np['name']}]")
        if want_story:
            story = gen_story(target, text)
            db.add_message(session, "assistant", story)
            return {
                "reply": story, "action": "switch", "persona": target,
                "tts_voice": _voice_for(target), "panel": "story",
            }
        greeting = (
            f"你好呀，我是{np['name']}，{np['tag']}。从现在开始由我来陪着你～"
            "想聊天、听故事，还是了解酒店？直接吩咐我就行。"
        )
        db.add_message(session, "assistant", greeting)
        return {"reply": greeting, "action": "switch", "persona": target, "tts_voice": _voice_for(target), "panel": None}

    intent = classify(text)
    persona = _persona(persona_pid)

    # 2) 方言问候
    if intent in ("dialect_yue", "dialect_sichuan"):
        if intent == "dialect_yue":
            reply = "你好呀，欢迎入住示例酒店！我系" + persona["name"] + "啊，今晚想倾偈定系听个古仔呀？"
            voice = "xiaonuan_yue" if persona_pid == "xiaonuan" else "azhe"
            vv = _voice_for(persona_pid, "xiaonuan_yue" if persona_pid == "xiaonuan" else None)
        else:
            reply = "你好噻，欢迎入住示例酒店！我是" + persona["name"] + "，想摆哈龙门阵，还是听个故事嘛？"
            vv = _voice_for(persona_pid, "azhe_sichuan" if persona_pid == "azhe" else None)
            voice = "azhe_sichuan" if persona_pid == "azhe" else "azhe"
        vv = config.VOICE_MAP.get(voice) or persona["voice"]
        db.add_message(session, "assistant", reply)
        return {"reply": reply, "action": "dialect", "persona": persona_pid, "tts_voice": vv, "panel": None}

    # 3) 隐私合规
    if intent == "checkout":
        if re.search(r"退房|清除|清空|删除", text) and not re.search(r"开麦|关麦|麦克风开|麦克风关", text):
            db.checkout(session)
            reply = "已为您办理退房，本房间全部对话与个人数据已清除（退房即清，隐私无忧）。欢迎再次入住示例酒店，再见～"
            db.add_message(session, "assistant", reply)
            return {"reply": reply, "action": "checkout_done", "persona": persona_pid, "tts_voice": persona["voice"], "panel": "privacy"}
        if re.search(r"关麦|麦克风关", text):
            return {"reply": "好的，麦克风已关闭，指示灯熄灭；需要我时再打开就好。", "action": "mic_off", "persona": persona_pid,
                    "tts_voice": persona["voice"], "panel": "privacy"}
        if re.search(r"开麦|麦克风开", text):
            return {"reply": "麦克风已开启，指示灯亮起，我随时待命。", "action": "mic_on", "persona": persona_pid,
                    "tts_voice": persona["voice"], "panel": "privacy"}
        reply = ("隐私保护说明：您的对话仅保存在本房间本地，退房时对我说「我要退房」即可一键清除全部数据；"
                 "电视下方有麦克风物理开关与常亮指示灯，敏感信息不会上传。")
        db.add_message(session, "assistant", reply)
        return {"reply": reply, "action": "privacy", "persona": persona_pid, "tts_voice": persona["voice"], "panel": "privacy"}

    # 4) 晚安故事 / 睡前场景
    if intent == "story":
        story = gen_story(persona_pid, text)
        db.add_message(session, "assistant", story)
        is_sleep = bool(re.search(r"晚安|睡觉|睡吧|哄睡|睡前", text))
        if is_sleep:
            update_dev(db.get_devices(), light={"on": True, "brightness": 18}, tv={"volume": 6}, curtain={"open": 0})
        return {"reply": story, "action": "sleep_scene" if is_sleep else "story",
                "persona": persona_pid, "tts_voice": persona["voice"], "panel": "story"}

    # 5) 设备控制
    if intent == "device":
        cmd = parse_device_command(text)
        if cmd == "ac_temp":
            m = re.search(r"(\d{1,2})", text.replace(" ", ""))
            if m:
                reply, d = ac_temp_reply(int(m.group(1)))
            else:
                reply, d = exec_device("ac_on")
        elif cmd == "light_dim":
            m = re.search(r"(\d{1,3})", text.replace(" ", ""))
            reply, d = light_dim_reply(int(m.group(1))) if m else exec_device("light_on")
        elif cmd == "curtain_pct":
            m = re.search(r"(\d{1,3})", text.replace(" ", ""))
            reply, d = curtain_reply(int(m.group(1))) if m else exec_device("curtain_open")
        else:
            reply, d = exec_device(cmd or "tv_on")
        db.add_message(session, "assistant", reply)
        return {"reply": reply, "action": "device", "persona": persona_pid,
                "tts_voice": persona["voice"], "panel": "devices", "devices": d}

    # 6) 实时天气（联网工具）
    if intent == "weather":
        city = extract_city(text) or "杭州"
        info = fetch_weather(city, text)
        reply = info or f"抱歉，联网天气服务暂时不可用，没能查到{city}的实时天气，稍后再问我试试～"
        db.add_message(session, "assistant", reply)
        return {"reply": reply, "action": "chat", "persona": persona_pid,
                "tts_voice": persona["voice"], "panel": None}

    # 7) 实时网页搜索（联网工具）
    if intent == "search":
        import re as _re
        q = _re.sub(r"^(帮我|请|麻烦|你给我|给我|帮忙|搜索一下|搜一下|查一下|查一查|查查|百度一下|上网查|网上查|搜索|查|搜)", "", text)
        q = q.strip(" ，。！？、的")
        info = web_search(q or text)
        reply = info or "联网搜索暂时不可用（网络或必应访问受限）。您可以问我酒店本地信息，比如早餐时间、附近美食、退房政策～"
        db.add_message(session, "assistant", reply)
        return {"reply": reply, "action": "chat", "persona": persona_pid,
                "tts_voice": persona["voice"], "panel": None}

    # 8) 知识库问答（RAG）
    if intent == "kb":
        reply, hits = kb_answer(text, persona_pid)
        db.add_message(session, "assistant", reply)
        return {"reply": reply, "action": "kb", "persona": persona_pid,
                "tts_voice": persona["voice"], "panel": "kb",
                "sources": [{"title": h["title"], "content": h["content"][:80]} for h in hits]}

    # 7) 情绪陪伴聊天（默认）
    history = db.get_history(session, limit=10)
    msgs = [{"role": "system", "content": persona["system"]}]
    msgs += [{"role": m["role"], "content": m["content"]} for m in history if m["role"] in ("user", "assistant")]
    llm_reply = await_llm(msgs) if ai.available else None
    reply = llm_reply if llm_reply else fallback_reply(persona, text)
    db.add_message(session, "assistant", reply)
    return {"reply": reply, "action": "chat", "persona": persona_pid,
            "tts_voice": persona["voice"], "panel": None}


# ---------------------------------------------------------------- TTS
@app.post("/api/tts")
async def tts(req: TtsReq):
    voice = config.VOICE_MAP.get(req.voice_id) or req.voice_id
    try:
        buf = io.BytesIO()
        proxy = os.environ.get("EDGE_TTS_PROXY") or "http://127.0.0.1:10808"
        com = edge_tts.Communicate(req.text, voice, rate="+0%", proxy=proxy)
        async for chunk in com.stream():
            if chunk["type"] == "audio":
                buf.write(chunk["data"])
        data = buf.getvalue()
        if not data:
            raise RuntimeError("empty audio")
        return Response(content=data, media_type="audio/mpeg")
    except Exception as e:  # noqa: BLE001
        return JSONResponse({"detail": f"TTS failed: {e}"}, status_code=502)


# ---------------------------------------------------------------- 各类 API
@app.get("/api/init")
def init_info():
    return {
        "hotel": config.HOTEL_NAME,
        "personas": {
            pid: {"name": p["name"], "tag": p["tag"], "gender": p["gender"], "voice": p["voice"]}
            for pid, p in config.PERSONAS.items()
        },
        "devices": db.get_devices(),
        "news": NEWS,
        "ai_available": ai.available,
        "model": ai.model if ai.available else "offline-fallback",
    }


@app.get("/api/news")
def news():
    return {"items": NEWS}


@app.get("/api/devices")
def devices():
    return db.get_devices()


@app.post("/api/devices/set")
def device_set(req: DeviceSetReq):
    db.update_device(req.key, req.patch)
    return db.get_devices()


@app.get("/api/kb")
def kb_list():
    return {"entries": knowledge.all_kb()}


@app.post("/api/kb/import")
def kb_import(req: KbImportReq):
    kid = knowledge.add_kb(req.category, req.title, req.content)
    return {"id": kid, "ok": True}


@app.delete("/api/kb/{kid}")
def kb_delete(kid: int):
    knowledge.delete_kb(kid)
    return {"ok": True}


@app.post("/api/privacy/checkout")
def do_checkout():
    db.checkout("guest")
    return {"ok": True, "message": "会话数据已清除"}


# ---------------------------------------------------------------- 前端静态托管
_dist = config.STATIC_DIR
if _dist.exists():
    app.mount("/", StaticFiles(directory=str(_dist), html=True), name="frontend")
    print(f"前端静态资源: {_dist}")


if __name__ == "__main__":
    import os as _os
    import uvicorn
    host = _os.environ.get("HOTEL_HOST", "127.0.0.1")
    port = int(_os.environ.get("HOTEL_PORT", "8000"))
    print(f"监听: {host}:{port}")
    uvicorn.run(app, host=host, port=port)
