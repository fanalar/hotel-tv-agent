"""本地部署版「酒店电视 AI 智能体情绪价值」演示原型 - 后端配置"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR.parent / "frontend" / "dist"  # Vite 构建产物

# ---- 环境变量加载：优先 backend/.env，其次回退 Hermes 主配置 ----
def _load_dotenv(path: Path):
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

_load_dotenv(BASE_DIR.parent / ".env")


DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1").rstrip("/")
DEEPSEEK_MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-v4-flash")
DATA_DIR = Path(os.environ.get("HOTEL_DATA_DIR", str(BASE_DIR.parent / "data")))
DB_PATH = DATA_DIR / "hotel_agent.db"
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

HOTEL_NAME = os.environ.get("HOTEL_NAME", "示例酒店")   # 演示用虚构酒店名，可换成任意酒店

PERSONAS = {
    "xiaonuan": {
        "name": "小暖", "gender": "female",
        "tag": "温柔管家 · 小姐姐",
        "voice": "zh-CN-XiaoxiaoNeural",
        "system": f"你是{HOTEL_NAME}客房里的 AI 陪伴管家「小暖」，一个温柔体贴、声音甜美的姐姐型管家。你负责陪客人聊天、提供情绪价值、讲晚安故事、回答酒店与本地旅游问题。语气温暖有耐心、口语化、适度关心，回复简洁（一般不超过80字，除非用户要求讲故事或长内容）。现在你在酒店的客房电视上与客人对话。",
    },
    "azhe": {
        "name": "阿哲", "gender": "male",
        "tag": "儒雅管家 · 小哥哥",
        "voice": "zh-CN-YunxiNeural",
        "system": f"你是{HOTEL_NAME}客房里的 AI 陪伴管家「阿哲」，一个儒雅稳重又不失幽默的哥哥型管家。你负责陪客人聊天、提供情绪价值、讲晚安故事、回答酒店与本地旅游问题。语气礼貌大方、略带幽默感、口语化，回复简洁（一般不超过80字，除非用户要求讲故事或长内容）。现在你在酒店的客房电视上与客人对话。",
    },
}

# 方言/多音色语音映射（Edge TTS 音色）
VOICE_MAP = {
    "xiaonuan": "zh-CN-XiaoxiaoNeural",        # 小暖·温柔女声（普通话）
    "xiaonuan_yue": "zh-HK-HiuMaanNeural",     # 小暖·粤语女声
    "azhe": "zh-CN-YunxiNeural",               # 阿哲·儒雅男声（普通话）
    "azhe_sichuan": "zh-CN-Sichuan-YunxiNeural",  # 阿哲·四川话
    "azhe_dongbei": "zh-CN-liaoning-XiaobeiNeural",  # 备用东北口音
}

