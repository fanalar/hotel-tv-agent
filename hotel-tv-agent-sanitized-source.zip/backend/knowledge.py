"""本地知识库检索：关键词 + 2-gram 召回（对标原项目 retrieveKnowledge）"""
import re

from database import all_kb, add_kb, delete_kb

_PUNCT = re.compile(r"[\s，。！？、；：""''（）【】《》,.!?;:()\[\]·\-—~～]")


def _grams(text: str, n: int = 2):
    t = _PUNCT.sub("", text)
    return {t[i : i + n] for i in range(max(0, len(t) - n + 1))}


def retrieve(query: str, top_k: int = 2) -> list[dict]:
    """关键词 + 2-gram 相似度召回"""
    qg = _grams(query)
    qk = set(_PUNCT.sub("", query))
    scored = []
    for e in all_kb():
        title_g, content_g = _grams(e["title"]), _grams(e["content"])
        title_k = set(_PUNCT.sub("", e["title"]))
        content_k = set(_PUNCT.sub("", e["content"]))
        s = 0.0
        inter = qg & content_g
        if inter:
            s += len(inter) * 1.0
        inter_t = qg & title_g
        if inter_t:
            s += len(inter_t) * 2.0
        kw_hit = sum(1 for k in qk if k in content_k or k in title_k)
        s += kw_hit * 0.3
        if s > 0:
            scored.append((s, e))
    scored.sort(key=lambda x: -x[0])
    return [e for _, e in scored[:top_k]]
